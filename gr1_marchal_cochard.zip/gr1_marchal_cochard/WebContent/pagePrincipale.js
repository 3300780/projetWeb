function Message(id,auteur,text,date,comments){
	this.id = id;
	this.auteur = auteur;
	this.text = text;
	this.date = date;
	
	if (comments == undefined) {
		comments = [];
	}
	
	this.comments = comments;
}

Message.prototype.getHtml = function(){
	var s = '<div class="mess" name="msg" id="Message_'+this.id+'">'+
			'<div class="liens" id="suppr_msg"><img src="poubelle.jpg" title="supprimer le message" alt="suppr msg" onclick="return suppressionMessage('+this.id+');"/></div>'+
			'<div class="text">'+this.text+'</div>'+
			'<div class="date">'+this.date+'</div>'+
			'<div class="login" onclick="return makeMainPanel('+getFromId(this.auteur)+',-1)" >'+this.auteur+'</div>'+
			'<ul class="commentaire" id="Commentaire_'+this.id+'">'+
			'<li><div class="listeCom">commentaire+ '+
			'<ul class=n1>';
	
	for ( var i = 0; i < this.comments.length; i++) {
		if(this.comments[i]!=undefined){
			s += '<li><div class="com" id="com_'+this.id+this.comments[i].getHtml();
		}
	}
	console.log("mess"+this.id);
	if(this.comments == undefined || this.comments.length == 0){
		s += '<li><div class="com" id="newCom"><form name="fc" method="get" action="javascript:(ajoutCommentaire('+this.id+','+this.id+'));">'+
		 '<label for="comment">Commenter :</label>'+
		 '<textarea id="comment'+this.id+'" name="comment" cols="18" rows="1"></textarea>'+
		 '<input class="bouton" type="submit" value="commenter"/>'+
		 '</form></div></li>';
	}else{
		s += '<li><div class="com" id="newCom"><form name="fc" method="get" action="javascript:(ajoutCommentaire('+this.id+this.comments.lenght+','+this.id+'));">'+
		 '<label for="comment">Commenter :</label>'+
		 '<textarea id="comment'+this.id+this.comments.lenght+'" name="comment" cols="18" rows="1"></textarea>'+
		 '<input class="bouton" type="submit" value="commenter"/>'+
		 '</form></div></li>';
	}
	
	s += '</ul></li></ul></div>';
	
	return s;
}

function Comment(id,auteur,texte,date){
	this.id = id;
	this.auteur = auteur;
	this.texte = texte;
	this.date = date;
}

Comment.prototype.getHtml = function(){
	var s = '_'+this.id+'>' +
			'<div class="liens" id="suppr_com"><img src="poubelle.jpg" title="supprimer le commentaire" alt="suppr com" onclick="return suppressionCommentaire('+this.id+');"/></div>'+
			'<div class="auteur_com" onclick="return makeMainPanel('+getFromId(this.auteur)+',-1)">'+this.auteur+'</div>'+
			'<div class="text_com">'+this.texte+'</div>'+
			'<div class="date_com">'+this.date+'</div>';
	return s;
}

function revival(key,value){
	if (value.comments != undefined && value.error == undefined) {
		var c = new Message(value.id, value.auteur, value.texte, value.date, value.comments);
		return c;
	}else if (value.texte != undefined) {
		var c = new Comment(value.id, value.auteur, value.texte, value.date);
		return c;
	}else if (key == 'date') {
		var d = new Date(value);
		return d;
	}else{
		return value;
	}
}

function setVirtualMessages(){
	localdb = [];
	follows = [];
	liste = [];
	
	var user1 = {"id":1, "login":"sly"};
	var user2 = {"id":2, "login":"job"};
	var user3 = {"id":4, "login":"fab"};
	
	liste.push(user1);
	liste.push(user2);
	liste.push(user3);
	
	follows[1] = new Set();
	follows[1].add(2);
	follows[1].add(4);
	
	follows[2] = new Set();
	follows[2].add(4);
	
	follows[4] = new Set();
	follows[4].add(1);
	follows[4].add(2);
	follows[4].add(4);
	
	var com1 = new Comment(1, "fab", "hum", new Date());
	var com2 = new Comment(2, "sly", "ABC", new Date());
	var com3 = new Comment(3, "sly", "AAA", new Date());
	var coms = [];
	coms[0] = com1;
	coms[1] = com2;
	coms[2] = com3;
	
	var com4 = new Comment(4, "fab", "com4", new Date());
	var com5 = new Comment(5, "sly", "com5", new Date());
	var com6 = new Comment(6, "sly", "com6", new Date());
	var coms2 = [];
	coms2[0] = com4;
	coms2[1] = com5;
	coms2[2] = com6;
	
	localdb[2] = new Message(2, user1.login, "Message Alea", new Date(),coms);
	localdb[3] = new Message(3, user1.login, "Coucou", new Date(), new Array());
	localdb[4] = new Message(4, user2.login, "Hello world", new Date(),coms2);
}

function getFromLogin(id){
	if(!env.noConnection){
		//TODO
	}else{
		for(var user=0;user<liste.length;user++)	if (liste[user].id == id)	return liste[user].login;
		return -1;
	}
}

function getFromId(login){
	if(!env.noConnection){
		//TODO
	}else{
		for(var user=0;user<liste.length;user++)	if (liste[user].login == login)	return liste[user].id;
		return -1;
	}
}

function makeMainPanel(fromId,query){
	env.msgs = [];
	env.minId = -1;
	env.maxId = -1;
	
	env.fromId = fromId;
	env.follows=follows;
	
	env.fromLogin = getFromLogin(fromId);
	env.query; // on ne l'utilise pas pour l'instant
	$.clear_appear();
	var s = '<div class="logo" onclick="return makeMainPanel(-1,-1);"><img src="ATT00002.png" alt="logo" width="250" height="50"></div>'+
			'<div class="zone-recherche">'+
			'<center>'+
			'<form id="fr" method="get" action = "javascript:(recherche(this.fr))();">'+
			'<label for="recherche">Recherche :</label>'+
			'<input type="text" name="recherche"/>'+
			'<input class="bouton" type="submit" value="rechercher"/>'+
			'</form></center></div>'+
			'<div>'+
			'<center>'+
			'<div class="interieurLien">';
	
	if(env.fromId<0){
		s +='<div class="liens" id="perso" onclick="return makeMainPanel('+env.id+',-1);">'+env.login+'<br /></div>';
	}else if(env.fromId == env.id){
		s+="<div id=\"title\">Page de " + env.fromLogin + "</div><div id=\"add\"></div></div>";
	}else if(!env.follows[env.id].has(fromId)){
		s +='<div class="liens" id="perso" onclick="return makeMainPanel('+env.id+',-1);">'+env.login+'<br /></div>';
		s+='<div id="title"> Page de ' + env.fromLogin +'</div><div class="liens" id="add"><img src="suivre.png" title="suivre" alt="suivre" onclick="return follow('+env.id+','+env.fromId+');"/></div></div>';
	}else{
		s +='<div class="liens" id="perso" onclick="return makeMainPanel('+env.id+',-1);">'+env.login+'<br /></div>';
		s +='<div id="title">Page de '+ env.fromLogin + '</div><div class="liens" id="add"><img src="croix.jpeg" title="arreter de suivre" alt="arreter de suivre" onclick="return stopFollow('+env.id+','+env.fromId+');"></div></div>';
	}
	s+=	'<div class=\"liens\" id="connexion" onclick="javascript:(makeConnexionPanel())()">deconnexion</div>'+
 		'</div></center></div>'+
 		'<div class="corp">'+
 		'<div class="stat">'+
 		'<center><h3>Follower</h3></center>';
	if (env.fromId<0) {
		s+= '<div id="">'+getFollow(env.follows[env.id])+'</div></div>';
	}else{
		s+=	'<div id="">'+getFollow(env.follows[env.fromId])+'</div></div>';
	}
	s += '<div class="page">'+
		 '<div class="newMessage">'+
		 '<form id="fm" method="get" action="javascript:(ajoutMessage(this.fm))();">'+
		 '<center><label for="message">Nouveau Message</label><br />'+
		 '<textarea id="message" name="message" cols="100" rows="3"></textarea><br />'+
		 '<input class="bouton" type="submit" value="Ajouter"/></center>'+
		 '</form></div>'+
		 '<div class="listeMessage" id="listeMessage"></div>'+
		 '</div></div>';
	
	css = '<link href="pagePrincipale.css" rel="stylesheet" type="text/css" />';
	$('#css').html(css);
	$('#body').html(s);
	$.clear_appear();
	completeMessages();
	
}

function maxIdMsg(){
	var max=0
	for (var i=0; i<localdb.length; i++){
		if(localdb[i] != undefined && localdb[i].id>max){
			max=localdb[i].id
		}
	}
	return max;
}

function ajoutMessage(f){
	var message = f.message.value;
	var ok = verifFormMessage(message);
	var maxId = maxIdMsg();
	
	if (ok) {
		if(!env.noConnection){
			//TODO
		}else{
			localdb[localdb.length]=new Message(maxId+1, env.login, message, new Date(), new Array());
			$.clear_appear();
			completeMessages()
			makeMainPanel(env.fromId,-1);
			return true;
		}
	}else{
		return false;
	}
}

function ajoutCommentaire(id,id_msg){
	//var com = f.fc.comment4.value;
	//console.log("com : "+com);
	//var coms = tabcom;
	var ok = true; // verifFormCom(com);
	
	if (ok) {
		if(!env.noConnection){
			//TODO
		}else{
			f=document.getElementById("comment"+id).value;
			console.log("f : "+ f);
			c = new Comment(env.id, env.login, f, new Date());
			
			for(var i=0; i<localdb.length; i++){
				if (localdb[i] != undefined && localdb[i].id==id_msg){
					localdb[i].comments.push(c);
					console.log("local : "+ localdb[i].comments);
					$.clear_appear();
					completeMessages()
					makeMainPanel(env.fromId,-1);
					return true;;
				}
			}
			//coms.push(c);
			$.clear_appear();
			completeMessages()
			makeMainPanel(env.fromId,-1);
			return true;
		}
	}else{
		return false;
	}
}

function verifFormCom(com){
	if(com.length == 0){
		func_Erreur_Commentaire("Aucun commentaire n'ecrit.");
		return false;
	}else if (com.length > 100){		
		func_Erreur_Commentaire("Le commentaire est trop long.");
		return false;
	}else{
		return true;
	}
}

function func_Erreur_Commentaire(msg){
	var msgBox = "<center><div id='erreurCommentaire'>" + msg + "</div></center>";
	var oldMsg = $("#erreurCommentaire");
	
	if(oldMsg.length==0){
		$("#fc").append(msgBox);
	}else{
		oldMsg.replaceWith(msgBox);
	}
}

function suppressionMessage(id){
	for(var i=0; i<localdb.length; i++){
		if(localdb[i]!=undefined){
			if(localdb[i].id==id){
				localdb[i]=undefined;
				$.clear_appear();
				completeMessages()
				makeMainPanel(env.fromId,-1);
				break;
			}
		}
	}
}

function suppressionCommentaire(id){
	for(var i=0; i<localdb.length; i++){
		if(localdb[i]!=undefined){
			for(var j=0; j<localdb[i].comments.length; j++){
				if(localdb[i].comments[j]!=undefined){
					if(localdb[i].comments[j].id==id){
						localdb[i].comments[j]=undefined;
						$.clear_appear();
						completeMessages()
						makeMainPanel(env.fromId,-1);
						break;
					}
				}
			}
		}
	}
}

function verifFormMessage(message){
	if(message.length == 0){
		func_Erreur_Message("Aucun message ecrit.");
		return false;
	}else if (message.length > 100){		
		func_Erreur_Message("Le message est trop long.");
		return false;
	}else{
		return true;
	}
}

function func_Erreur_Message(msg){
	var msgBox = "<center><div id='erreurMessage'>" + msg + "</div></center>";
	var oldMsg = $("#erreurMessage");
	
	if(oldMsg.length==0){
		$("#fm").append(msgBox);
	}else{
		oldMsg.replaceWith(msgBox);
	}
}

function recherche(f){
	//console.log(f);
	var i = f.recherche.value;
	var ok = verifFormRecherche(i);
	
	
	if(ok){
		if(!env.noConnection){
			//TODO
		}else{
			env.fromId = getFromId(i);
			makeMainPanel(env.fromId,-1);
			return true;
		}
	}else{
		return false;
	}
}

function verifFormRecherche(i){
	if(i == undefined){
		func_Erreur_Recherche("Auncun login n'a ete renseigner.");
		return false;
	}else if(getFromId(i)==-1){
		func_Erreur_Recherche("Aucune personne avec ce login.");
		return false;
	}else{
		return true;
	}
}

function func_Erreur_Recherche(msg){
	var msgBox = "<center><div id='erreurRecherche'>" + msg + "</div></center>";
	var oldMsg = $("#erreurRecherche");
	
	if(oldMsg.length==0){
		$("#fr").append(msgBox);
	}else{
		oldMsg.replaceWith(msgBox);
	}
}

function getFollow(f){
	if(!env.noConnection){
		//TODO
	}else{
		s = '';
		if(f != undefined){
			if(env.id == 2) follows[2].delete(2);
			for (var item of f.values()){
				if(item != env.fromId && item != env.id){
					s += '<div class=liens id=user_'+item+' onclick="return makeMainPanel('+item+',-1);">'+getFromLogin(item)+'</div>';
			
				}
			}
		}
	}
	return s;
}

function follow(){
	if(!env.noConnection){
		//TODO
	}else{
		//console.log(env.follows[env.id]);
		env.follows[env.id].add(env.fromId);
		makeMainPanel(env.fromId,-1);
		//console.log(env.follows[env.id]);
		return true;
	}
}

function stopFollow(){
	if(!env.noConnection){
		//TODO
	}else{
		//console.log(env.follows[env.id]);
		env.follows[env.id].delete(env.fromId);
		makeMainPanel(env.fromId,-1);
		//console.log(env.follows[env.id]);
		return true;
	}
}

function completeMessages(){
	if(!env.noConnection){
	//TODO
	}else{
		var tab = getFromLocalDb(env.fromId,-1,env.minId,10);
		//console.log(JSON.stringify(tab));
		//tab=JSON.stringify(tab);
		$(".listeMessage").append(tab);
		completeMessagesReponse(tab);
	}
}

function getFromLocalDb(from, minId, maxId, nbMax){
	var tab=localdb;
	var nb=0;
	var res=[];
	
	if(from<0){
		for(var i=localdb.length-1; i>=0; i--){
			nb++;
			if(nb>nbMax){
				break;
			}else{
				res.push(tab[i]);
			}
		}
	}else{
		for(i=0; i<localdb.length;i++){
			if(tab[i] != undefined){
				if(tab[i].id==from){
					res.push(tab[i]);
				}else{
					if(follows[from] != undefined && follows[from].has(tab[i].id)){
						res.push(tab[i]);
					}
				}
			}
		}
	}
	return res;
}

function completeMessagesReponse(rep){
	var tab = rep;	
	var lastid = undefined;
	for(var i=0; i<tab.length-1; i++){
		if(tab[i] != undefined){
			$(".listeMessage").append(tab[i].getHtml());
			
			env.msgs[tab[i].id]=tab[i];
			
			if(tab[i].id>env.maxId){
				env.maxId=tab[i].id;
			}
			if((env.maxId<0)||(tab[i].id<env.minId)){
				env.minId=tab[i].id;
			}
			lastid=tab[i].id;
		}
		
	}

	$("#Message_"+lastid).appear();
	$.force_appear();
}

function init(){
	env={};
	env.noConnection=true;
	setVirtualMessages();
	env.id=2;
	env.login="job";
	makeMainPanel(-1,-1);
	//makeEnregistrementPanel();
	
	//makeConnexionPanel();
	
}

function makeConnexionPanel(){
	s = '<div id="connexion_main">'+
		'<h1>Ouvrir une session</h1>'+
		'<form method="get" onsubmit="return connexion(this);" >'+
		'<div class="connexion_ids"><label for="login"><spam>Login</spam></label><input type="text" name="login" id="login"/></div>'+
		'<div class="connexion_ids"><label for="pssd"><spam>Mot de passe</spam></label><input type="password" name="pssd" id="pssd"/></div>'+
		'<div class="connexion_links">'+
		'<div id="link1"><a href="#">mot de passe perdu</a></div>'+
		'<div id="link2"><a href="javascript:(makeEnregistrementPanel())()">pas deja inscrit ?</a></div>'+
		'<div class="connexion_bottom"><input type="submit" value="connexion" /></div>'+
		'</div>'+
		'</form>'+
		'</div>';
	css = '<link href="ouvertureSession.css" rel="stylesheet" type="text/css" />';
	$("#css").html(css);
	$("#body").html(s);
}

function connexion(f){
	event.preventDefault();
	var login = f.login.value;
	var pssd = f.pssd.value;
	console.log(login);
	console.log(pssd);
	var ok = verifFormConnexion(login,pssd);
	
	if(ok){
		connecte(login,pssd);
		return true;
	}else{	
		return false;
	}
}

function reponseConnection(rep) {
	console.log(rep);
	if (rep.erreur == undefined) {
		env.key = rep.key;
		env.id = rep.id;
		env.login = getFromLogin(env.id);
		/*env.follows[rep.id] = new Set();
		
		rep.follows.forEach(function(valeur){
			env.follows[rep.id].add(valeur);
		});*/
		if (env.noConnection) {
			follows[rep.id] = new Set();
			rep.follows.forEach(function(valeur){
				follows[rep.id].add(valeur);
			});
		}
		makeMainPanel(-1,-1);
	} else {
		func_Erreur(rep.erreur);
	}
	console.log(env.id);
	console.log(env.login);
}

function verifFormConnexion(login, pssd){
	if (login.length == 0) {
		func_Erreur("Login obligatoire");
		return false;
	}

	if (login.length > 20) {
		func_Erreur("Login trop long");
		return false;
	}
	
	if (pssd.length == 0){
		func_Erreur("Password obligatoire");
		return false;
	}

	if (pssd.length > 20) {
		func_Erreur("Password trop long");
		return false;
	}
	return true;
}

function makeEnregistrementPanel(){
	s = '<div id="enregistrement_main"> ' +
		'<h1>Enregistrement</h1> ' +
		'<form methode="GET" action="javascript:(fonction(){})()" /> ' +
		'<div id="intitule"> ' +
		'<label for="prenom"><spam>Prenom</spam></label>'+
		'<label for="nom"><spam>Nom</spam></label>'+
		'</div>'+
		'<div id="nomprenom">'+
		'<input type="text" name="prenom" id="prenom"/><input type="text" name="nom" id="nom"/>'+
		'</div>'+
		'<div id="log" class="identification">'+
		'<label for="log"><spam>Login</spam></label>'+
		'<input type="text" name="log"/>'+
		'</div>'+
		'<div id="email" class="identification">'+
		'<label for="email"><spam>Email</spam></label>'+
		'<input type="email" name="email"/>'+
		'</div>'+
		'<div class="identification">'+
		'<label for="mdp"><spam>Mot de Passe</spam></label>'+
		'<input type="password" name="mdp"/>'+
		'</div>'+
		'<div id="retaper" class="identification">'+
		'<label for="mdp"><spam>Confirmer</spam></label>'+
		'<input type="password" name="mdp"/>'+
		'</div>'+
		'<div id="final">'+
		'<center>'+
		'<input type="submit" value="Enregistrer"/>'+
		'<input type="button" name="lien1" value="Annuler" onclick="javascript:(makeConnexionPanel())()">'+ 
		'</center>'+
		'</div>'+
		'</form>'+
		'</div>';
	css = '<link href="enregistrement.css" rel="stylesheet" type="text/css" />';
	$("#css").html(css);
	$("#body").html(s);
}

function func_Erreur(msg){
	var msgBox = "<center><div id='erreurConnect'>" + msg + "</div></center>";
	var oldMsg = $("#erreurConnect");
	
	if(oldMsg.length==0){
		$("form").append(msgBox);
	}else{
		oldMsg.replaceWith(msgBox);
	}
}

function connecte(login,password){
	//console.log(env.noConnection);
	if(!env.noConnection){
	r="0";
		$.ajax({
			type:"GET", url:"/User/LoginServlet", 
			dataType:"json", 
			data:"login="+login+"&pssd="+password+"&root="+r, 
			error:function(xhr, status, err) {func_Erreur(status + ": " + err);},//(jqXHR,textStatus,errorTherron){ alert(textStatus); }, 
			success:function(rep){ reponseConnexion(rep); }
			});			
	}else{
		reponseConnection({"key":password, "id":getFromId(login), "login":login, "follows":[2,4]});
	}
}

function refreshMessages(login){
	if(!noConnexion){
		$.ajax({
			type:"GET",
			url:"/Message/GetMessageServlet",
			dataType:"text/plain",
			data:"key="+env.key+"&query=&from="+env.fromId+"&id_min="+env.maxId+"&id_max=-1ńb=-1",
			error:function(jqXHR,testStatus,errorThrown){ alert(testStatus); },
			success:refreshMessagesReponse
		});
	}else{
		refreshMessagesReponse(JSON.stringify(getFromLocalDb(env.fromId,env.maxId,-1,-1)));
	}
}

function refreshMessagesReponse(rep){
	var tab=JSON.parse(rep,revival);
	
	if(tab.erreur!=undifined){
		alert(erreur);
	}else{
		for(var i=0; i<tab.length; i++){
			$("#listeMessage").prepend(tab[i].getHtml());
			env.msgs[tab[i].id]=tab[i];
			if(tab[i].id>env.maxId){
				env.maxId=tab[i].id;
			}
		}
	}
}