function Message(id,auteur,text,date,comments){
	this.id = id;
	this.auteur = auteur;
	this.text = text;
	this.date = date;
	
	if (comments == undefined) {
		comments = [];
	}
	
	this.comments = comments;
}

Message.prototype.getHtml = function(){
	var s = '<div class="mess" id="Message_'+this.id+'">'+
			'<div class="text">'+this.text+'</div>'+
			'<div class="date">'+this.date+'</div>'+
			'<div class="login">'+this.auteur+'</div>'+
			'<ul class="commentaire" id="Commentaire_'+this.id+'">'+
			'<li><div class="listeCom">commentaire+ '+
			'<ul class=n1>';
	
	for ( var i = 0; i < this.comments.length; i++) {
		s += '<li><div class="com" id="com_'+this.id+this.comments[i].getHtml();
	}
	
	s += '</ul></li></ul></div>';
	
	return s;
}

function Comment(id,auteur,texte,date){
	this.id = id;
	this.auteur = auteur;
	this.texte = texte;
	this.date = date;
}

Comment.prototype.getHtml = function(){
	var s = '_'+this.id+'>' +
			'<div class="auteur_com">'+this.auteur+'</div>'+
			'<div class="text_com">'+this.texte+'</div>'+
			'<div class="date_com">'+this.date+'</div>';
	return s;
}

function revival(key,value){
	if (value.comments != undefined && value.error == undefined) {
		var c = new Message(value.id, value.auteur, value.texte, value.date, value.comments);
		return c;
	}else if (value.texte != undefined) {
		var c = new Comment(value.id, value.auteur, value.texte, value.date);
		return c;
	}else if (key == 'date') {
		var d = new Date(value);
		return d;
	}else{
		return value;
	}
}

function setVirtualMessages(){
	localdb = [];
	follows = [];
	
	var user1 = {"id":1, "login":"sly"};
	var user2 = {"id":2, "login":"job"};
	var user3 = {"id":4, "login":"fab"};
	
	follows[1] = new Set();
	follows[1].add(2);
	follows[1].add(4);
	
	follows[2] = new Set();
	follows[2].add(4);
	
	follows[4] = new Set();
	follows[4].add(1);
	follows[4].add(2);
	follows[4].add(3);
	
	var com1 = new Comment(1, "user3", "hum", new Date());
	var com2 = new Comment(2, "user1", "ABC", new Date());
	var com3 = new Comment(3, "user1", "AAA", new Date());
	var coms = [];
	coms[0] = com1;
	coms[1] = com2;
	coms[2] = com3;
	
	localdb[2] = new Message(2, user1.login, "Message Alea", new Date(),coms);
	localdb[3] = new Message(2, user1.login, "Coucou", new Date(),null);
	localdb[4] = new Message(4, user2.login, "Hello world", new Date(),coms);
}


function makeMainPanel(fromId,fromLogin,query){
	env.msgs = [];
	env.minId = -1;
	env.maxId = -1;
	
	env.fromId = fromId;
	env.follows=follows;
	
	env.fromLogin = fromLogin;
	env.query; // on ne l'utilise pas pour l'instant
	$.clear_appear();
	var s = '<div class="logo"><img src="ATT00002.png" alt="logo" width="250" height="50"></div>'+
			'<div class="zone-recherche">'+
			'<center>'+
			'<form method="get" action="profil.html">'+
			'<label for="recherche">Recherche :</label>'+
			'<input type="text" name="recherche"/>'+
			'<input class="bouton" type="submit" value="rechercher"/>'+
			'</form></center></div>'+
			'<div>'+
			'<center>'+
			'<div class="interieurLien">';
	
	console.log("fmgoihergnpmkngn");
		
	if(env.fromId<0){
		s +='<div class="liens" id="perso" onclick="javascript:(makeMainPanel('+env.id+','+env.login+',-1))()">'+env.login+'<br /></div>';
			
	}else if(env.fromId == env.id){
		s+="<div class=\"liens\" id=\"title\">Page de " + fromLogin + "</div><div id=\"add\"></div></div>";
	}else if(!env.follows[env.id].has(fromId)){
		s +='<div class="liens" id="perso" onclick="javascript:(makeMainPanel('+env.id+','+env.login+',-1))()">'+env.login+'<br /></div>';
		s+="<div id=\"title\"> Page de " + fromLogin + "</div><div id=\"add\"><img class=\"liens\" src=\"suivre.png\" title=\"suivre\" alt=\"suivre\" onclick=\"javascript:follow()\"/></div></div>";
	}else{
		s += '<div class="liens" id="perso" onclick="javascript:(makeMainPanel('+env.id+','+env.login+',-1))()" >'+env.login+'<br /></div>';
		s += "<div id=\"title\">Page de "+ fromLogin + "</div><div class=\"liens\" id=\"add\"><img src=\"croix.jpeg\" title=\"arreter de suivre\" alt=\"arreter de suivre\" onclick=\"javascript:stopFollow()\"/></div></div>";
	}
	s += '<div class=\"liens\" id="connexion" onclick="javascript:(makeConnexionPanel())()">deconnexion</div>'+
		 '</div></center></div>'+
		 '<div class="corp">'+
		 '<div class="stat">'+
		 '<center><h3>Statistiques</h3></center>'+
		 '<div id="">Lien</div></div>'+
		 '<div class="page">'+
		 '<div class="newMessage">'+
		 '<form method="get" action="">'+
		 '<center><label for="message">Nouveau Message</label><br />'+
		 '<textarea name="message" cols="100" rows="3"></textarea><br />'+
		 '<input class="bouton" type="submit" value="Ajouter"/></center>'+
		 '</form></div>'+
		 '<div class="listeMessage" id="listeMessage"></div>'+
		 '</div></div>';
	
	css = '<link href="pagePrincipale.css" rel="stylesheet" type="text/css" />';
	$('#css').html(css);
	$('#body').html(s);
	$.clear_appear();
	completeMessages();
	
}

function follow(){
	return true;
}

function stopFollow(){
	return true;
}

function completeMessages(){
	if(!env.noConnection){
	//TODO
	}else{
		var tab = getFromLocalDb(env.fromId,-1,env.minId,10);
		console.log(JSON.stringify(tab));
		//tab=JSON.stringify(tab);
		$(".listeMessage").append(tab);
		completeMessagesReponse(tab);
	}
}

function getFromLocalDb(from, minId, maxId, nbMax){
	var tab=localdb;
	var nb=0;
	var res=[];
	
	if(from<0){
		for(var i=localdb.length-1; i>=0; i--){
			nb++;
			if(nb>nbMax){
				break;
			}else{
				res.push(tab[i]);
			}
		}
	}else{
		for(i=0; i<localdb.length;i++){
			if(tab[i] != undefined){
				if(tab[i].id==from){
					res.push(tab[i]);
				}else{
					if(follows[from] != undefined && follows[from].has(tab[i].id)){
						res.push(tab[i]);
					}
				}
			}
		}
	}
	return res
}

function completeMessagesReponse(rep){
	var tab = rep;	
	var lastid = undefined;
	for(var i=0; i<tab.length-1; i++){
		if(tab[i] != undefined){
			$(".listeMessage").append(tab[i].getHtml());
			
			env.msgs[tab[i].id]=tab[i];
			
			if(tab[i].id>env.maxId){
				env.maxId=tab[i].id;
			}
			if((env.maxId<0)||(tab[i].id<env.minId)){
				env.minId=tab[i].id;
			}
			lastid=tab[i].id;
		}
		
	}

	$("#Message_"+lastid).appear();
	$.force_appear();
}

function init(){
	env={};
	env.noConnection=true;
	setVirtualMessages();
	env.id = 2;
	env.login = "job";
	makeMainPanel(1,"sly",-1);
	//makeEnregistrementPanel();
	
	//makeConnexionPanel();
	
}

function makeConnexionPanel(){
	s = '<div id="connexion_main">'+
		'<h1>Ouvrir une session</h1>'+
		'<form method="get" onsubmit="return connexion(this);" >'+
		'<div class="connexion_ids"><label for="login"><spam>Login</spam></label><input type="text" name="login" id="login"/></div>'+
		'<div class="connexion_ids"><label for="pssd"><spam>Mot de passe</spam></label><input type="password" name="pssd" id="pssd"/></div>'+
		'<div class="connexion_links">'+
		'<div id="link1"><a href="#">mot de passe perdu</a></div>'+
		'<div id="link2"><a href="javascript:(makeEnregistrementPanel())()">pas deja inscrit ?</a></div>'+
		'<div class="connexion_bottom"><input type="submit" value="connexion" /></div>';
		'</div>'+
		'</form>'+
		'</div>';
	css = '<link href="ouvertureSession.css" rel="stylesheet" type="text/css" />';
	$("#css").html(css);
	$("#body").html(s);
}

function connexion(f){
	event.preventDefault();
	var login = f.login.value;
	var pssd = f.pssd.value;
	var ok = verifFormConnexion(login,pssd);
	
	if(ok){
		connecte(login,pssd);
		return true;
	}else	return false;
}

function reponseConnection(rep) {
	console.log(rep);
	if (rep.erreur == undefined) {
		env.key = rep.key;
		env.id = rep.id;
		env.login = rep.login;
		/*env.follows[rep.id] = new Set();
		
		rep.follows.forEach(function(valeur){
			env.follows[rep.id].add(valeur);
		});*/
		if (env.noConnection) {
			follows[rep.id] = new Set();
			rep.follows.forEach(function(valeur){
				follows[rep.id].add(valeur);
			});
		}
		makeMainPanel(-1,-1,-1);
	} else {
		func_Erreur(rep.erreur);
	}
}

function verifFormConnexion(login, pssd){
	if (login.length == 0) {
		func_Erreur("Login obligatoire");
		return false;
	}

	if (login.length > 20) {
		func_Erreur("Login trop long");
		return false;
	}
	
	if (pssd.length == 0){
		func_Erreur("Password obligatoire");
		return false;
	}

	if (pssd.length > 20) {
		func_Erreur("Password trop long");
		return false;
	}
	return true;
}

function makeEnregistrementPanel(){
	s = '<div id="enregistrement_main"> ' +
		'<h1>Enregistrement</h1> ' +
		'<form methode="GET" action="javascript:(fonction(){})()" /> ' +
		'<div id="intitule"> ' +
		'<label for="prenom"><spam>Prenom</spam></label>'+
		'<label for="nom"><spam>Nom</spam></label>'+
		'</div>'+
		'<div id="nomprenom">'+
		'<input type="text" name="prenom" id="prenom"/><input type="text" name="nom" id="nom"/>'+
		'</div>'+
		'<div id="log" class="identification">'+
		'<label for="log"><spam>Login</spam></label>'+
		'<input type="text" name="log"/>'+
		'</div>'+
		'<div id="email" class="identification">'+
		'<label for="email"><spam>Email</spam></label>'+
		'<input type="email" name="email"/>'+
		'</div>'+
		'<div class="identification">'+
		'<label for="mdp"><spam>Mot de Passe</spam></label>'+
		'<input type="password" name="mdp"/>'+
		'</div>'+
		'<div id="retaper" class="identification">'+
		'<label for="mdp"><spam>Confirmer</spam></label>'+
		'<input type="password" name="mdp"/>'+
		'</div>'+
		'<div id="final">'+
		'<center>'+
		'<input type="submit" value="Enregistrer"/>'+
		'<input type="button" name="lien1" value="Annuler" onclick="javascript:(makeConnexionPanel())()">'+ 
		'</center>'+
		'</div>'+
		'</form>'+
		'</div>';
	css = '<link href="enregistrement.css" rel="stylesheet" type="text/css" />';
	$("#css").html(css);
	$("#body").html(s);
}

function func_Erreur(msg){
	var msgBox = "<center><div id='erreurConnect'>" + msg + "</div></center>";
	var oldMsg = $("#erreurConnect");
	
	if(oldMsg.length==0){
		$("form").append(msgBox);
	}else{
		oldMsg.replaceWith(msgBox);
	}
}

function connecte(login,password){
	console.log(env.noConnection);
	if(!env.noConnection){
		$.ajax({
			type:"GET", url:"/User/LoginServlet", 
			dataType:"json", 
			data:"login="+login+"pssd="+password, 
			error:function(jqXHR,textStatus,errorTherron){ alert(textStatus); }, 
			success:function(rep){ reponseConnexion(rep); }
			});			
	}else{
		reponseConnection({"key":3250, "id":1, "login":login, "follows":[2,4]});
	}
}

function refreshMessages(login){
	if(!noConnexion){
		$.ajax({
			type:"GET",
			url:"/Message/GetMessageServlet",
			dataType:"text/plain",
			data:"key="+env.key+"&query=&from="+env.fromId+"&id_min="+env.maxId+"&id_max=-1ńb=-1",
			error:function(jqXHR,testStatus,errorThrown){ alert(testStatus); },
			success:refreshMessagesReponse
		});
	}else{
		refreshMessagesReponse(JSON.stringify(getFromLocalDb(env.fromId,env.maxId,-1,-1)));
	}
}

function refreshMessagesReponse(rep){
	var tab=JSON.parse(rep,revival);
	
	if(tab.erreur!=undifined){
		alert(erreur);
	}else{
		for(var i=0; i<tab.length; i++){
			$("#listeMessage").prepend(tab[i].getHtml());
			env.msgs[tab[i].id]=tab[i];
			if(tab[i].id>env.maxId){
				env.maxId=tab[i].id;
			}
		}
	}
}