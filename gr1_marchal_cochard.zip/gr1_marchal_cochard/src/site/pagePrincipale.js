function Message(id,auteur,texte,date,comments){
	this.id = id;
	this.auteur = auteur;
	this.texte = texte;
	this.date = date;
	
	if (comments == undefined) {
		comments = [];
	}
	
	this.comments = comments;
}

Message.prototype.getHtml() = function(){
	var s = '<div class="mess" id=\"Message_'+this.id+'">'+
			'<div class="text">'+this.text+'</div>'+
			'<div class="date">'+this.date+'</div>'+
			'<div class="login">'+this.login+'</div>';
			'<ul class="commentaire" id=\"Commentaire_'+this.id+'">'+
			'<li><div class="listeCom">commentaire+ '+
			'<ul class=n1>';
	
	for ( var i = 0; i < this.comments.length; i++) {
		s += '<li><div class="com" id="com_'+this.id+comments[i].getHtml();
	}
	
	s += '</ul></div></li></ul></div></div>';
	
	return s;
}

function Comment(id,auteur,texte,date){
	this.id = id;
	this.auteur = auteur;
	this.texte = texte;
	this.date = date;
}

Comment.prototype.getHtml() = function(){
	var s = '_'+this.id+'">com1</div></li>';
	return s;
}

function revival(key,value){
	if (value.comments != undefined) {
		var c = new Message(value.id, value.auteur, value.texte, value.date, value.comments);
		return c;
	}else if (value.texte != undefined) {
		var c = new Comment(value.id, value.auteur, value.texte, value.date);
		return c;
	}else if (key == 'date') {
		var d = new Date(value);
		return d;
	}else{
		return value;
	}
}

function setVirtualMessages(){
	lacaldB = [];
	follows = [];
	
	var user1 = {"id":1, "login":"sly"};
	var user2 = {"id":2, "login":"job"};
	var user3 = {"id":4, "login":"fab"};
	
	follows[1] = new Set();
	follows[1].add(2);
	follows[1].add(4);
	
	follows[2] = new Set();
	follows[2].add(4);
	
	follows[4] = new Set();
	follows[4].add(1);
	
	var com1 = new Commentaire(1, user3, "hum", new Date());
	var com1 = new Commentaire(2, user1, "ABC", new Date());
	var com1 = new Commentaire(3, user1, "AAA", new Date());
	
	localdb[2] = new Message(2, user1, "Message Alea", new Date());
	localdb[4] = new Message(4, user2, "blabla", new Date());
	
	.
	.
	.
	.
}

function init(){
	noConnection = true;
	env = new Object();
	setVirtualMessages();
}

function makeMainPanel(fromId,fromLogin,query){
	env.msg = [];
	env.minId = -1;
	env.maxId = -1;
	
	env.fromId = fromId;
	env.fromLogin = fromLogin;
	console.log(env.fromLogin);
	env.query // on ne l'utilise pas pour l'instant
	
	//entete
	var s = '<!doctype>'+
			'<HTML>'+
			'<HEAD>'+
			'<title>'+title+'</title>'+
			'<link href="pagePrincipale.css" rel="stylesheet" type="text/css" />'+
			'<link rel="shortcut icon" href="ATT00002.png">'+
			'</head>';
	
	if(env.fromId<0){
		tab = getFrontLocalDb(env.id,env.minId,env.maxId,10);
		message = "";
		for(var i=0;i<tab.length;i++){
			messages += tab[i].getHtml();
		}
		s+="<div id=\"title\"> Actualites </div>"+
			'<div class="logo"><img src="ATT00002.png" alt="logo" width="250" height="50"></div>'+
			'<div class="zone-recherche">'+
			'<center>'+
			'<form method="get" action="profil.html">'+
			'<label for="recherche">Recherche :</label>'+
			'<input type="text" name="recherche"/>'+
			'<input class="bouton" type="submit" value="rechercher"/>'+
			'</form></center></div>'+
			'<div class="liens">'+
			'<center>'+
			'<div class="interieurLien">'+
			'<div onclick="javascript:makeMainPanel('+env.id+','+env.login+',"")>'+env.id+'</a><br />'+
			'<div class="lien" onclick="javascript:deconnexion()">deconnexion</a>'+
			'</div></center></div>'+
			'<div class="corp">'+
			'<div class="stat">'+
			'<center><h3>Statistiques</h3></center>'+
			'<div id="">Lien</div></div>'+
			'<div class="page">'+
			'<div class="newMessage">'+
			'<form method="get" action=''>'+
			'<center><label for="message">Nouveau Message</label><br />'+
			'<textarea name="message" cols="100" rows="3"></textarea><br />'+
			'<input class="bouton" type="submit" value="Ajouter"/></center>'+
			'</form></div>'+
			'<div class="listeMessage" >'+messages+'</div>'+
			'</div></div></body></html>';
	}else{
		if(env.fromId==env.id){
			s+="<div id=\"title\">Page de " + fromLogin + "</div>";
		}
		else if(!env.follows.has(env.fromId)){
			s+="<div id=\"title\">Page de " + fromLogin + "</div><div id=\"add\"><img src=\"Image/add.png\" title=\"suivre\" alt=\"suivre\" onclick=\"javascript:follow()\"/></div></div>";
		}else{
			s+="<div id=\"title\"> Actualites </div><div id=\"add\"><img src=\"Image/add.png\" title=\"arreter de suivre\" alt=\"arreter de suivre\" onclick=\"javascript:stopFollow()\"/></div></div>";
		}
	}
}

