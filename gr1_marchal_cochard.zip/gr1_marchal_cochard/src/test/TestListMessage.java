package test;

import services.message.ListMessageProfil;

public class TestListMessage {

	public static void main(String[] args) {
		System.out.println(ListMessageProfil.listeMessageProfil("OFyDCUFFzyuweOAcTNLMhEOeWoeeoKz").toString());
	}

}
