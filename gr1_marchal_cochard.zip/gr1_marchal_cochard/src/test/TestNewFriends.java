package test;

import services.friends.NewFriends;

public class TestNewFriends {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(FriendsTools.recupeId("qqqDNBiKvXFbEXXRNOKKzjTvbqUBRiq"));
		//System.out.println(FriendsTools.recupeLog("123460"));
		//System.out.println(FriendsTools.insertFriends("123460", "123459"));
		System.out.println(NewFriends.newFriends("sctmWulrpAyzgimNJaBwDyfGEaucNnO", "123463"));
	}
}
