package test;

import services.user.CreateUser;

/**
 * Test CreateUser
 * @author Louise et Charlotte
 *
 */
public class TestCreateUser {
	public static void main(String[] args) {
		System.out.println(CreateUser.create("louise", "marchal","test@outlok.fr","loulou","123").toString());
	}
}
