package test;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.GregorianCalendar;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.Mongo;

public class TestMongoDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Mongo m = new Mongo("li328.lip6.fr",27130);
			DB db = m.getDB("gr1_2017_COCHARD_MARCHAL");
			DBCollection coll = db.getCollection("comments");
			BasicDBObject obj = new BasicDBObject();
			obj.put("author_id",328);
			obj.put("author_name","toto");
			obj.put("text", "blabla");
			
			GregorianCalendar cal = new java.util.GregorianCalendar();
			Date date = cal.getTime();
			obj.put("date", date);
			
			coll.insert(obj);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
