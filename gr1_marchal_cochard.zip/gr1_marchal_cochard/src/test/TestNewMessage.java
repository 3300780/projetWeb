package test;

import serviceTools.MessageTools;
import services.message.ListMessageProfil;
import services.message.NewMessage;

public class TestNewMessage {

	public static void main(String[] args) {
		System.out.println(MessageTools.deleteAllMessage());
		System.out.println(MessageTools.nbMessage());
		System.out.println(NewMessage.newMessage("jCsqwddlRjfPHRBWpSyxPgkedembuUl", "bbb").toString());
		System.out.println(MessageTools.nbMessage());
		System.out.println(NewMessage.newMessage("jCsqwddlRjfPHRBWpSyxPgkedembuUl", "aaa").toString());
		System.out.println(MessageTools.nbMessage());
		System.out.println(ListMessageProfil.listeMessageProfil("jCsqwddlRjfPHRBWpSyxPgkedembuUl").toString());
	}

}
