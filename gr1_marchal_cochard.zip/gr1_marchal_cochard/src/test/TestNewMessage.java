package test;

import services.message.ListMessageProfil;
import services.message.NewMessage;

public class TestNewMessage {

	public static void main(String[] args) {
		System.out.println(NewMessage.newMessage("RKQzhoXuZnnwkShVtbQRVWLxqjXpCtx", "cocote").toString());
		System.out.println(ListMessageProfil.listeMessageProfil("RKQzhoXuZnnwkShVtbQRVWLxqjXpCtx").toString());
	}

}
