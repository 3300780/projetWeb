package test;

import serviceTools.MessageTools;
import services.message.ListMessageProfil;
import services.message.NewMessage;

public class TestNewMessage {

	public static void main(String[] args) {
		System.out.println(MessageTools.deleteAllMessage());
		System.out.println(MessageTools.nbMessage());
		System.out.println(NewMessage.newMessage("TCjxMEnVcQKPPOLQfnsmWnSILRMkkCx", "bbb").toString());
		System.out.println(ListMessageProfil.listeMessageProfil("TCjxMEnVcQKPPOLQfnsmWnSILRMkkCx").toString());

		System.out.println(MessageTools.nbMessage());
		System.out.println(NewMessage.newMessage("TCjxMEnVcQKPPOLQfnsmWnSILRMkkCx", "aaa").toString());
		System.out.println(ListMessageProfil.listeMessageProfil("TCjxMEnVcQKPPOLQfnsmWnSILRMkkCx").toString());
		System.out.println(MessageTools.nbMessage());
	}

}
