package test;

import services.user.StopFollow;

public class TestStopFollow {

	public static void main(String[] args) {
		System.out.println(StopFollow.stopFollow("VhVOahHLnIUBELbhmBXLNtLBSGAMANF", "123468"));
	}

}
