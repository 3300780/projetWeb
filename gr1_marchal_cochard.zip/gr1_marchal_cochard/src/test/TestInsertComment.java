package test;

import services.message.PostComment;

public class TestInsertComment {
	public static void main(String[] args) {
		System.out.println(PostComment.postComment("lkdCkcHguyzWBDpYQRdTijXTmMWGYQH", "58a9c7a3f97508f65624d410", "cool").toString());
	}
}
