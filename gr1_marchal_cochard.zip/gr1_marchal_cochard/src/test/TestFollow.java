package test;

import services.user.Follow;

public class TestFollow {

	public static void main(String[] args) {
		System.out.println(Follow.follow("lkdCkcHguyzWBDpYQRdTijXTmMWGYQH", "123468"));
	}

}
