package test;

import services.user.Login;

/**
 * Effectue un test de connexion
 * @author Louise et Charlotte
 *
 */
public class TestUserLogin {

	public static void main(String[] args) {
		System.out.println(Login.login("lou", "123456","1").toString());
		//System.out.println(UserTools.checkPassword("coc", "123"));
		//System.out.println(UserTools.userConnect("loulou"));
		//System.out.println(UserTools.recupereId("loulou"));
	}

}
