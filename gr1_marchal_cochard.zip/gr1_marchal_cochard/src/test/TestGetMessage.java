package test;

import services.message.GetMessage;
import services.message.ListMessageProfil;

public class TestGetMessage {

	public static void main(String[] args) {
		System.out.println(ListMessageProfil.listeMessageProfil("DlowKCWUeHMWXsKfIKeQRNnQSWKvNiX"));
		System.out.println(GetMessage.getMessage("DlowKCWUeHMWXsKfIKeQRNnQSWKvNiX", "", "123469", "0", "1", "0", "5"));
	}

}
