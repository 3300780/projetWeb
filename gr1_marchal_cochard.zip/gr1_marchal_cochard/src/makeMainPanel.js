function Message(id,auteur,texte,date,comments){
	this.id=id; 
	this.auteur=auteur; 
	this.texte=texte; 
	this.date=date; 
	if(comments==undifined){
		this.comments=[];
	}
	this.comments=comments;
}

message.prototype.getHtml=function(){
	var s="<div id=\"message_" + this.id + "\" class=\"message\">";
	s+="<div id=\"texte_" + this.id + "\" class=\"texte\" >" + this.texte + "</div>";
	s+="<div id=\"date_" + this.id + "\" class=\"date\" >" + this.date + "</div>";
	s+="<div id=\"auteur_" + this.id + "\" class=\"auteur\" >" + this.auteur + "</div>";
	s+="<div id=\"comments_" + this.id + "\" class=\"comments\" >";
	s+="<ul>";
	for(var c in this.comments){
		s+="<li> + "c.getHtml()" + </li>";
	}
	s+="</ul></div></div>";
	return s;
}
	


function Comments(id,auteur,texte,date){
	this.id=id;
	this.auteur=auteur;
	this.texte=texte;
	this.date=date;
}

comments.prototype.getHtml=function(){
	var s="div id=\"comment_" + this.id + "\" class=\"comment\">";
	s+="<div id=\"date_" + this.id + "\" class=\"date\" >" + this.date + "</div>";
	s+="<div id=\"auteur_" + this.id + "\" class=\"auteur\" >" + this.auteur + "</div>";
	s+="<div id=\"texte_" + this.id + "\" class=\"texte\" ><p>" + this.texte + "</p></div>";
	s+="</div>";
	return s;
}

function setVirtualMessages(){
	localdb=[];
	follows=[];
	
	var user1={"id":1,"login":"sly"};
	var user2={"id":2,"login":"john"};
	var user3={"id":4,"login":"fab"};
	
	follows[1]=new Set();
	follows[1].add(2);
	follows[1].add(4);
	
	follows[2]=new Set();
	follows[2].add(4);
	
	follows[4]=new Set();
	follows[4].add(1);
	
	var com1=new Comments(1,user3,"hum", new Date());
	var com2=new Comments(2,user1,"ABC", new Date());
	
	localdb[2]=new Message(2,user1,"message aleatoire", new Date());
	localdb[4]=new Message(4,user2,"blabla",new Date(),[com1,com2]);
}

function init(){
	noConnection=true;
	env=new Object();
	setVirtualMessage();
}


function MakeMainPanel(fromId, fromLogin, query){
	env.msg=[];
	env.minId=-1;
	env.maxId=-1;
	
	if(fromId==undefined){
		fromId=-1;
	}
	
	env.fromId=fromId;
	env.fromLogin=fromLogin;
	
	console.log(env.fromLogin);
	env.query=query;
	
	var s = "<!doctype><HTML><HEAD><title>TWISTER</title><link href='pagePrincipale.css' rel='stylesheet' type='text/css' /></head>";
	
	if(env.fromId<0){
		s+="<div id=\"title\"> Actualites </div>";
	}else{
		if(env.fromId==env.id){
			s+="<div id=\"title\">Page de " + fromLogin + "</div>";
		}
		else if(!env.follows.has(env.fromId)){
			s+="<div id=\"title\">Page de " + fromLogin + "</div><div id=\"add\"><img src=\"Image/add.png\" title=\"suivre\" alt=\"suivre\" onclick=\"javascript:follow()\"/></div></div>";
		}else{
			s+="<div id=\"title\"> Actualites </div><div id=\"add\"><img src=\"Image/add.png\" title=\"arreter de suivre\" alt=\"arreter de suivre\" onclick=\"javascript:stopFollow()\"/></div></div>";
		}
	}
	
	
}
