import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import services.message.DeleteMessage;

/**
 * Classe de representation d'un servlet servant a supprimer un message
 * @author Louise,Charlotte
 */
public class DeleteMessageServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		JSONObject res;
		@SuppressWarnings("unchecked")
		Map<String, String[]> pars = req.getParameterMap();
		if (pars.containsKey("key") && pars.containsKey("id_com") && pars.containsKey("text")){
			String key = req.getParameter("key");
			String id_com = req.getParameter("id_com");
			String text = req.getParameter("text");
			res = DeleteMessage.deleteMessage(key, id_com, text);
		}else{
			res = ErrorTools.serviceRefused("Les arguments requis sont la cle de connection de l'utilisateur, l'id du commentaire a supprimer ainsi que le texte a supprimer", "error");
		}
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String r = res.toString();
		out.println("<html><body>"+r+"</body></html>");
	}
	
}
