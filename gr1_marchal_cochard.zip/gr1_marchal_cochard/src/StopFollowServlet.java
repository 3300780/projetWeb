import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import services.user.StopFollow;

public class StopFollowServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		JSONObject res;
		@SuppressWarnings("unchecked")
		Map<String, String[]> pars = req.getParameterMap();
		if (pars.containsKey("key") && pars.containsKey("id_user")){
			String key = req.getParameter("key");
			String id_user = req.getParameter("id_user");
			res = StopFollow.stopFollow(key, id_user);
		}else{
			res = ErrorTools.serviceRefused("Les arguments requis sont la cle de connection de l'utilisateur, l'id de l'utilisateur suivi", "error");
		}
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String r = res.toString();
		out.println("<html><body>"+r+"</body></html>");
	}
}
