package serviceTools;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * envoie une reponse avec un message et une cle
 * @author Louise et Charlotte
 *
 */
public class ResponseTools {
	/**
	 * Envoie un message
	 * @param message message a transmettre
	 * @param key cle a transmettre
	 * @return un objet JSON
	 */
	public static JSONObject serviceAccepted(ArrayList<String> message, ArrayList<String> key){
		JSONObject obj = new JSONObject();
		try {
			for (int i = 0; i < message.size(); i++) {
				obj = obj.put(message.get(i),key.get(i));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
	}
}
