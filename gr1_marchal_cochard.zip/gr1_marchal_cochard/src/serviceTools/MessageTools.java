package serviceTools;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;

import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;

/**
 * Verifie la validite des informations
 * @author Louise et Charlotte
 */
public class MessageTools {
	/**
	 * Permet d'inserer un message dans un document MongoDB
	 * @param key la clef de connection de l'utilisateur
	 * @param text le message text a inserer
	 */
	public static void insertMessage(String key, String text) {
		String id = FriendsTools.recupeId(key);
		String login = FriendsTools.recupeLog(id);
		
		try {
			Mongo m = new Mongo("li328.lip6.fr", 27130);
			DB db = m.getDB("gr1_2017_marchal_cochard");
			DBCollection coll= db.getCollection("Comments");
			BasicDBObject obj = new BasicDBObject();
			obj.put("author_id", id);
			obj.put("text", text);
			GregorianCalendar c = new java.util.GregorianCalendar();
			Date date_du_jour = c.getTime();
			obj.put("date", date_du_jour);
			obj.put("author_name", login);
			obj.put("like", new ArrayList<JSONObject>());
			coll.insert(obj);
		} catch (UnknownHostException e) {
			System.out.println(ErrorTools.serviceRefused("Error insert connexion", "6").toString());
		}
	}
	
	/**
	 * Recherche la liste de smessages poster par l'utilisateur
	 * @param key	cle de l'utilisateur
	 * @return le texte du commentaire 
	 */
	public static JSONObject searchMessageUser(String key) {
		String id_author = FriendsTools.recupeId(key);
		try {
			Mongo m = new Mongo("li328.lip6.fr", 27130);
			DB db = m.getDB("gr1_2017_marchal_cochard");
			DBCollection coll= db.getCollection("Comments");
			BasicDBObject query = new BasicDBObject();
			query.put("author_id", id_author);
			DBCursor cursor = coll.find(query);
			
			JSONObject liste = new JSONObject();
			JSONObject obj = new JSONObject();
			
			if (! cursor.hasNext()) {
				return ErrorTools.serviceRefused("No message", "21");
			}else{
				while(cursor.hasNext()){
					DBObject c = cursor.next();
					String id_com = c.get("_id").toString();
					String author_id = c.get("author_id").toString();
					String text = c.get("text").toString();
					String date = c.get("date").toString();
					String author_name = c.get("author_name").toString();
					@SuppressWarnings("unchecked")
					ArrayList<JSONObject> like = (ArrayList<JSONObject>) c.get("like");
					obj.put("_id", id_com);
					obj.put("author_id", author_id);
					obj.put("text",text);
					obj.put("date", date);
					obj.put("author_name",author_name);
					obj.put("like", like);
					liste.put(id_com, obj);
				}
				return liste;
			}
		} catch (UnknownHostException e) {
			System.out.println(ErrorTools.serviceRefused("Research failed : Fatal error", "13").toString());
		}catch (JSONException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return ErrorTools.serviceRefused("Research failed", "13");
	}
	
	/**
	 * Recupere l'id de l'auteur du message grace a l'id du commentaire specifie
	 * @param id_com l'id du commentaire
	 * @return l'id de l'auteur du commentaire
	 */
	public static String recupereIdAuthor(String id_com, String text) {
		try {
			Mongo m = new Mongo("li328.lip6.fr", 27130);
			DB db = m.getDB("gr1_2017_marchal_cochard");
			
			DBCollection coll= db.getCollection("Comments");
			BasicDBObject query = new BasicDBObject();
			BasicDBObject select = new BasicDBObject();
			
			//query.put("_id", id_com);
			query.put("text", text);
			
			select.put("_id", 0);
			select.put("author_id", 1);
			
			DBCursor cursor = coll.find(query,select);
			System.out.println(cursor.hasNext());
			if (cursor.hasNext()) {
				String s = cursor.next().toString();
				String[] t = s.split(" : ");
				String [] t1=t[1].split("}");
				String[] t2=t1[0].split("\"");
				System.out.println("t2[1] "+t2[1]);
				return t2[1];
			}
			return "";
		} catch (UnknownHostException e) {
			System.out.println(ErrorTools.serviceRefused("Recup problem", "17"));
		}
		return "error";
	}
	
	/**
	 * Verifie l'utilisateur est le meme que l'auteur du message
	 * @param key la clef de l'utilisateur
	 * @param id_com l'id du commentaire
	 * @param text message
	 * @return true si ce sont les m�me, false sinon
	 */
	public static boolean correspondance(String key, String id_com, String text) {
		String id_user = FriendsTools.recupeId(key);
		if (id_user == "")	System.out.println(ErrorTools.serviceRefused("id does not correspond to the user's key", "18"));
		if (id_user == "error")	System.out.println(ErrorTools.serviceRefused("Recup Problem", "17"));
		String id_com_author = MessageTools.recupereIdAuthor(id_com, text);
		if (id_com_author == "" || id_com_author == "error")	System.out.println(ErrorTools.serviceRefused("Recup problem", "17").toString()); 
		System.out.println("id_user"+id_user+"id_com_author"+id_com_author+"!");
		return id_user.equals(id_com_author);
	}
	
	/**
	 * Supprime un message d'un utilisateur
	 * @param text le text du message
	 * @param key la clef de l'utilisateur
	 * @return true si le message a ete supprime, false sinon
	 */
	public static boolean delete(String text, String key) {
		try {
			Mongo m = new Mongo("li328.lip6.fr", 27130);
			DB db = m.getDB("gr1_2017_marchal_cochard");
			DBCollection coll= db.getCollection("Comments");
			BasicDBObject query = new BasicDBObject();
			query.put("text",text);
			query.put("author_id", FriendsTools.recupeId(key));
			
			DBCursor cursor = coll.find(query);
			
			if (cursor.hasNext()) {
				coll.remove(cursor.next());
				return true;
			}
			return false;
		} catch (UnknownHostException e) {
			System.out.println(ErrorTools.serviceRefused("Error delete message", "14"));
		}
		return false;
	}
}