package serviceTools;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.regex.Pattern;

import services.user.Logout;
import DB.Database;

/**
 * Verifie la validite des informations
 * @author Louise et Charlotte
 *
 */
public class UserTools {
	/**
	 * Verifie si l utilisatur existe
	 * @param login identifiant de l utilisateur a verifier
	 * @return true si existe, false sinon
	 */
	public static boolean userExist(String login){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT * FROM Users u WHERE u.login=\""+login+"\"";
			ResultSet res = st.executeQuery(query);
			boolean r = res.next();
			st.close();
			co.close();
			return r;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	/**
	 * Verifie si le mot de passe est correcte
	 * @param login identifiant de  l utilisateur
	 * @param mdp mot de passe a verifier
	 * @return true si le mot de passe est correcte, false sinon
	 */
	public static boolean checkPassword(String login, String mdp){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT * FROM Users u WHERE u.login=\""+login+"\" AND u.pssd="+mdp;
			ResultSet res = st.executeQuery(query);
			boolean t = res.next();
			st.close();
			co.close();
			return t;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	/**
	 * verifie si l utilisateur est deja connecte ATENTION !!!!!! A VOIR PROF
	 * @param login identifiant de l utilisateur
	 * @return true si l utilisateur est deja connecte, false sinon
	 */
	public static boolean userConnect(String login){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String id = recupereId(login);
			if (id == "error")	return false; 
			String query = "SELECT * FROM Connection c WHERE c.id="+id;
			ResultSet res = st.executeQuery(query);
			boolean r = res.next();
			st.close();
			co.close();
			return r;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	public static void keyExpired(){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT `key` FROM Connection WHERE sysdate()-`tmp`>30";
			ResultSet res = st.executeQuery(query);
			while(res.next()){
				UserTools.deconnexion(res.getString("key"));
			}
			st.close();
			co.close();
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
	}
	
	/**
	 * ajoute l utilisateur a la liste d utilisateur connecte
	 * @param login identifiant de l utilisateur
	 * @param status savoir si on se connecte en tant que root ou user
	 * @return un message de confirmation
	 */
	public static String insertConnexion(String login, String status){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String key = generateKey();
			String id = recupereId(login);
			if (id == "error" || id == "")	return "error";
			String query = "INSERT INTO Connection VALUES(\""+key+"\","+id+",null,"+status+")";
			int res = st.executeUpdate(query);
			st.close();
			co.close();
			if(res == 1)	return key;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return "error";
		
	}
	
	/**
	 * verifie si une valeur est null
	 * @param val valeur a verifier
	 * @return true si la valeur est null, false sinon
	 */
	public static boolean isNull(String val){
		return val==null;
	}
	
	/**
	 * Cree un utilisateur dans la base de donnee
	 * @param prenom de l utilisateur
	 * @param nom de l utilisateur
	 * @param adresse de l utilisateur
	 * @param login identifiant de l utilisateur
	 * @param mdp mot de passe de l utilisateur
	 * @return true si creation reussit, false sinon
	 */
	public static boolean insertUserBD(String prenom, String nom, String adresse, String login, String mdp){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "INSERT INTO Users VALUES(null,\""+login+"\","+mdp+",\""+nom+"\",\""+prenom+"\",\""+adresse+"\")";
			int res = st.executeUpdate(query);
			st.close();
			co.close();
			if(res==1)	return true;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	/**
	 * Deconnecte un utilisateur
	 * @param key cle de connexion de l utilisateur
	 * @return true si deconnexion reussit, false sinon
	 */
	public static boolean deconnexion(String key){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "DELETE FROM Connection WHERE `key`=\""+key+"\"";
			int res = st.executeUpdate(query);
			st.close();
			co.close();
			if(res==1)	return true;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	/**
	 * Verifie dans la base de donnee de connexion si la cle existe
	 * @param key cle de connexion de l utilisateur
	 * @return true si la cle existe dans la base, false sinon
	 */
	public static boolean keyExists(String key){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT * FROM Connection c WHERE c.key=\""+key+"\"";
			ResultSet res = st.executeQuery(query);
			boolean r = res.next();
			st.close();
			co.close();
			return r;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	/**
	 * Verifie si l adresse de l utilisateur est valide
	 * @param adr adresse de  l utilisateur
	 * @return true si adresse valide, false sinon
	 */
	public static boolean correctAdresse(String adr){
		return Pattern.matches("\\w+@(\\w+\\.)+\\w+", adr);
	}
	
	/**
	 * Genere une cle de connexion
	 * @return une chaine de caractere contenant la cle
	 */
	public static String generateKey(){
		String key="";
		Random r = new Random();

	    String alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	    for (int i = 0; i < 31; i++) {
	        key += alphabet.charAt(r.nextInt(alphabet.length()));
	    } 
		return key;
	}
	
	/**
	 * Recupere l id d un utilisateur dont le login est specifie
	 * @param login de  l utilisateur
	 * @return	l id de l utilisateur
	 */
	public static String recupereId(String login) {
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT idUsers FROM Users WHERE login=\""+login+"\"";
			ResultSet res = st.executeQuery(query);
			if (res.next()){
				String r = res.getString("idUsers");
				st.close();
				co.close();
				return r;
			}
			st.close();
			co.close();
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return "";
	}
	
	/**
	 * Test si le mot de passe existe deja
	 * @param mdp le mot de passe de la personne voulant se creer un compte
	 * @return true si le mot de passe existe, false sinon
	 */
	public static boolean passwordExist(String mdp) {
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT * FROM Users u WHERE u.pssd="+mdp;
			ResultSet res = st.executeQuery(query);
			boolean r = res.next();
			st.close();
			co.close();
			return r;
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		}
		return false;
	}
}
