package serviceTools;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Classe de representation des erreurs
 * @author Louise et Charlotte
 *
 */
public class ErrorTools {
	/**
	 * prend en argument un message et un code d'erreur et retourne l objet JSON associe
	 * @param msg message d erreur
	 * @param code code de l erreur
	 * @return un objet JSON
	 */
	public static JSONObject serviceRefused(String msg, String code){
		JSONObject obj=new JSONObject();
		
		try {
			obj.put("code",code);
			obj.put("msg", msg);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return obj;
	}
}
