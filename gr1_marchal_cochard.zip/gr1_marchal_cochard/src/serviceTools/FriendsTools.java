package serviceTools;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import DB.Database;

/**
 * Classe de representation des fonctions utiliser dans NewFriend
 * @author Charlotte Louise
 */
public class FriendsTools {
	/**
	 * Recupere l'id utilisateur grace a sa cle de connection
	 * @param key cle de connection
	 * @return l id utilisateur specifique a la cle donne en argument 
	 */
	public static String recupeId(String key) {
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT id FROM `Connection` WHERE `key`=\""+key+"\"";
			ResultSet res = st.executeQuery(query);
			
			if(res.next()){
				String id = res.getString("id");
				st.close();
				co.close();
				return id;
			}
			
			st.close();
			co.close();
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return "error";
	}
	
	/**
	 * Recupere le login de l'utilisateur grace a son id
	 * @param id_user id de l'utilisateur
	 * @return le login de l'utilisateur id
	 */
	public static String recupeLog(String id_user) {
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT login FROM Users WHERE idUsers="+id_user;
			ResultSet res = st.executeQuery(query);
				
			if(res.next()){
				String id=res.getString("login");
				st.close();
				co.close();
				return id;
			}
			
			st.close();
			co.close();
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return "error";
	}
	
	/**
	 * Insert une amitie dans la base de donnee Friends
	 * @param id_user id de  lutilisateur
	 * @param id_friend id du friends
	 * @return true si insertion reussis, false sinon
	 */
	public static boolean insertFriends(String id_user, String id_friend) {
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "INSERT INTO Friends VALUES("+id_user+","+id_friend+",CURRENT_TIMESTAMP)";
			int res = st.executeUpdate(query);
			st.close();
			co.close();
			if(res==1)	return true;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	/**
	 * Verifie si les utilisateurs sont deja amis
	 * @param id_user id de l utilisateur
	 * @param id_fri id de l amis
	 * @return true, si deja amis, false sinon
	 */
	public static boolean alreadyFriends(String id_user, String id_fri){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "Select * from Friends where `from`="+id_user+" and `to`="+id_fri;
			ResultSet res = st.executeQuery(query);
			boolean r = res.next();
			st.close();
			co.close();
			return r;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	/**
	 * Supprime un ami de la liste d'amis de l'utilisateur
	 * @param id_user l'id de l'utilisateur
	 * @param id_friend l'id de l'ami de l'utilisateur 
	 * @return true si la suppression a eu lieu, false sinon
	 */
	public static boolean deleteFriends(String id_user, String id_friend) {
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "delete from `Friends` where `from`="+id_user+" and `to`="+id_friend;
			int res = st.executeUpdate(query);
			st.close();
			co.close();
			if(res==1)	return true;
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return false;
	}
	
	/**
	 * List les amis de l'utilisateur
	 * @param key la cle de connection de l'utilisateur
	 * @return un objet JSON comportant la liste des amis de l'utilisateur
	 */
	public static String list(String key){
		Connection co;
		try {
			co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "Select `to` from `Friends` where `from`="+recupeId(key);
			ResultSet res = st.executeQuery(query);
			StringBuilder s = new StringBuilder();
			String log;
			while(res.next()){
				log = recupeLog(res.getString("to"));
				s.append(log+";");
			}
			st.close();
			co.close();
			return s.toString();
		} catch (ClassNotFoundException e) {
			System.out.println(ErrorTools.serviceRefused("Class not found", "16").toString());
		} catch (SQLException e) {
			System.out.println(ErrorTools.serviceRefused("ErrorJSON", "15").toString());
		}
		return "error";
	}
}
