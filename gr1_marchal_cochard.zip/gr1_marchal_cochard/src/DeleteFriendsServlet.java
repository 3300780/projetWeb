import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import services.friends.DeleteFriends;

/**
 * Classe de representation d'un Servlet permettant de supprimer un amis grace aux parametres de l'url
 * @author Charlotte, Louise
 */
public class DeleteFriendsServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		JSONObject res;
		@SuppressWarnings("unchecked")
		Map<String, String[]> pars = req.getParameterMap();
		if (pars.containsKey("key") && pars.containsKey("id_friend")){
			String key = req.getParameter("key");
			String id_friend = req.getParameter("id_friend");
			res = DeleteFriends.deleteFriends(key, id_friend);
		}else{
			res = ErrorTools.serviceRefused("Les arguments requis sont la cle de connection de l'utilisateur et l'id de l'ami qu'il souhaite suivre", "Error");
		}
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String r = res.toString();
		out.println("<html><body>"+r+"</body></html>");
	}
	
	
}
