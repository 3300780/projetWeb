package DB;

/**
 * Interface de constante de connection a la databe
 * @author Charlotte Louise
 */
public interface DBStatic {
	public static boolean mysql_pooling = false;
	public static String mysql_host = "132.227.201.129:33306";
	public static String mysql_bd = "gr1_cochard_marc";
	public static String mysql_username = "gr1_cochard_marc";
	public static String mysql_password = "cm1";
}
