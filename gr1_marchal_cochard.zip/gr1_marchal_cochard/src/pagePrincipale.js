function deconnexion() {
	
}
