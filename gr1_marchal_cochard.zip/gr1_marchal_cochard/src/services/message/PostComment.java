package services.message;


import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.MessageTools;
import serviceTools.UserTools;

/**
 * Poste un nouveau commentaire par rapport a un message donne
 * @author Louise et Chalotte
 *
 */
public class PostComment {
	/**
	 * Poste un nouveau commentaire par rapport a un message donne 
	 * @param key cle de connection
	 * @param id_msg identifiant du message concerne par le commentaire
	 * @param text texte du nouveau commentaire
	 * @return un JSON
	 */
	public static JSONObject postComment(String key, String id_msg, String text){
		UserTools.keyExpired();
		if (UserTools.isNull(key) || UserTools.isNull(text))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok)	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		if(!MessageTools.searchMessageId(id_msg)) return ErrorTools.serviceRefused("No message", "21");
		
		return MessageTools.insertComment(key, text, id_msg);
	}
}
