package services.message;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.MessageTools;
import serviceTools.UserTools;

public class PostComment {
	public static JSONObject postComment(String key, String id_msg, String text){
		if (UserTools.isNull(key) || UserTools.isNull(text))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok)	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		return MessageTools.insertComment(key, text, id_msg);
	}
}
