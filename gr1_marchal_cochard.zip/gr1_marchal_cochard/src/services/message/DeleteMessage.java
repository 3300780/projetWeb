package services.message;

import java.util.ArrayList;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.MessageTools;
import serviceTools.ResponseTools;
import serviceTools.UserTools;

/**
 * Supprime un message
 * @author Louise et Charlotte
 */
public class DeleteMessage {
	public static JSONObject deleteMessage(String key, String id_com, String text) {
		UserTools.keyExpired();
		if (UserTools.isNull(key) || UserTools.isNull(id_com))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok)	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		boolean same = MessageTools.correspondance(key, id_com, text);
		System.out.println("same "+same);
		if(!same)	return ErrorTools.serviceRefused("Key does not correspond to the author's id of the message", "12");
		
		boolean is_ok = MessageTools.delete(text, key);
		if (is_ok) {
			ArrayList<String> k = new ArrayList<String>();
			ArrayList<String> message = new ArrayList<String>();
			message.add("suppression");
			k.add("OK");
			return ResponseTools.serviceAccepted(message, k);
		}else{
			return ErrorTools.serviceRefused("suppression", "KO");
		}
	}
}
