package services.message;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.MessageTools;
import serviceTools.UserTools;

/**
 * Affiche une liste de message
 * @author Louise et Charlotte
 *
 */
public class GetMessage {
	/**
	 * affiche une liste de message
	 * @param key cle de session
	 * @param query les mots cles de la recherche (vide si pas de filtre)
	 * @param from identifiant de l'utilisateur duquel on souhate voir les messages associes
	 * @param princ 1 si page principale  
	 * @param id_max identifiant de chaque message inferieur a id_max
	 * @param id_min identifiant de chaque message superieur a id_min
	 * @param nb nombre de message a retourner
	 * @return un JSONObject
	 */
	public static JSONObject getMessage(String key, String query, String from, String princ, String id_max, String id_min, String nb){
		UserTools.keyExpired();
		if(!UserTools.keyExists(key))	return ErrorTools.serviceRefused("Key does not exist", "4");
		if(!UserTools.userExistId(from)) return ErrorTools.serviceRefused("User does not exist", "1");
		
		JSONObject msg = MessageTools.searchMessageByIdUser(from,id_min, id_max, nb);
		
		
		
		return msg;
	}
}
