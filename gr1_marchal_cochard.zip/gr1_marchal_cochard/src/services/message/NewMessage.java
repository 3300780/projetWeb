package services.message;
import java.util.ArrayList;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.MessageTools;
import serviceTools.ResponseTools;
import serviceTools.UserTools;

/**
 * Creer un nouveau message
 * @author Louise et Charlotte
 *
 */
public class NewMessage {
	/**
	 * Creation d'un nouveau message	
	 * @param key cle de connection de l'utilisateur
	 * @param text message a poster
	 * @return un JSON avec l'etat de l'insertion d'un message de l'utilisateur
	 */
	public static JSONObject newMessage(String key, String text) {
		UserTools.keyExpired();
		if (UserTools.isNull(key) || UserTools.isNull(text))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok)	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		MessageTools.insertMessage(key, text);
		
		ArrayList<String> k = new ArrayList<String>();
		k.add("OK");
		ArrayList<String> message = new ArrayList<String>();
		message.add("insertion");
		
		//return ResponseTools.serviceAccepted(message, k);
		return new JSONObject();
	}
}
