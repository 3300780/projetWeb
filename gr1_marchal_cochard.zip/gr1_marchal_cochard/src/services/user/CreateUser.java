package services.user;

import java.util.ArrayList;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.ResponseTools;
import serviceTools.UserTools;

/**
 * Creer un nouveau utilisateur dans la base de donnee
 * @author Louise et Charlotte
 *
 */
public class CreateUser {
	/**
	 * Effectue les tests necessaire a la creation d un utilisateur
	 * @param prenom de l'utilisate
	 * @param nom nom de l'utilisateur 
	 * @param adresse adresse mail de l utilisateur
	 * @param login identifiant de l utilisateur
	 * @param mdp mot de passe de l utilisateur
	 * @return une reponse JSONObject
	 */
	public static JSONObject create(String prenom, String nom, String adresse, String login, String mdp){
		UserTools.keyExpired();
		if (UserTools.isNull(prenom) || UserTools.isNull(nom) || UserTools.isNull(login) || UserTools.isNull(mdp) || UserTools.isNull(adresse))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		if (mdp.matches("[0-9]+") == false)	return ErrorTools.serviceRefused("Password does not an integer", "10");
		
		boolean is_user = UserTools.userExist(login);
		if (is_user)	return ErrorTools.serviceRefused("User already exist", "1");
		
		boolean is_adr = UserTools.correctAdresse(adresse);
		if(!is_adr)	return ErrorTools.serviceRefused("Wrong adress", "5");
		
		boolean mdp_exist = UserTools.passwordExist(mdp);
		if (mdp_exist)	return ErrorTools.serviceRefused("Password already exist", "20");
		
		ArrayList<String> key = new ArrayList<String>();
		if(UserTools.insertUserBD(prenom, nom, adresse, login, mdp))	key.add("OK");
		else	key.add("KO");
		
		ArrayList<String> message = new ArrayList<String>();
		message.add("insertion");
		
		return ResponseTools.serviceAccepted(message, key);
	}
		
}
