package services.user;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.FriendsTools;
import serviceTools.UserTools;

/**
 * Permet de suivre un utilisateur donne
 * @author Louise et Charlotte
 *
 */
public class Follow {
	/**
	 * Permet de suivre un utilisateur donne
	 * @param key cle de connection
	 * @param id_user identifiant de l'utilisateur que l'on souhaite suivre
	 * @return un objet JSON
	 */
	public static JSONObject follow(String key, String id_user){
		UserTools.keyExpired();
		if (UserTools.isNull(key) || UserTools.isNull(id_user))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		boolean is_user = UserTools.userExistId(id_user);
		if (!is_user)	return ErrorTools.serviceRefused("User does not exist", "1");
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok)	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		String id_k = FriendsTools.recupeId(key);
		
		boolean is_ok = UserTools.followHimself(id_user, id_k);
		System.out.println((is_ok));
		if(is_ok) return ErrorTools.serviceRefused("A user can't follow himself", "22");
		
		if(UserTools.isFollow(id_user, id_k)) return ErrorTools.serviceRefused("Already follow", "24");
		
		is_ok = UserTools.insertFollow(id_user,id_k);
		if(!is_ok) return ErrorTools.serviceRefused("Insert follow failed", "23");
		
		return new JSONObject();
	}
}
