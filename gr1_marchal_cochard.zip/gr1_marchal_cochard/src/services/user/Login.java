package services.user;

import java.util.ArrayList;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.ResponseTools;
import serviceTools.UserTools;
/**
 * Permet a un utilisateur de se connecter
 * @author Louise et Charlotte
 *
 */
public class Login {
	/**
	 * Effectuer les test necessaire a la connexion
	 * @param login identifiant de l utilisateur
	 * @param mdp mot de passe de l utilisateur
	 * @param root parametre permettant de savoir si l'utilisateur se connecte en tant que super utilisateur ou non
	 * @return une reponse sous forme d objet JSON
	 */
	public static JSONObject login(String login, String mdp, String root){
		UserTools.keyExpired();
		if (UserTools.isNull(login) || UserTools.isNull(mdp))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		boolean is_user = UserTools.userExist(login);
		if (!is_user)	return ErrorTools.serviceRefused("User does not exist", "1");
		
		boolean passwd_ok = UserTools.checkPassword(login, mdp);
		if (!passwd_ok)	return ErrorTools.serviceRefused("Wrong Password", "2");
		
		boolean connect_ok = UserTools.userConnect(login);
		if (connect_ok)	return ErrorTools.serviceRefused("Already connect", "3");
		
		String key = UserTools.insertConnexion(login, root);
		if (key == "error")	return ErrorTools.serviceRefused("Error insertion connexion", "6");
		
		ArrayList<String> k = new ArrayList<String>();
		String id = UserTools.recupereId(login);
		if (id == "error" || id == "")	return ErrorTools.serviceRefused("Error insertion connexion", "6");
		
		if (Integer.parseInt(root) == 1) root = "root";
		else	root = "user";
		
		String id_user = UserTools.recupereId(login);
		ArrayList<String> follows = new ArrayList<String>();
		follows=UserTools.friends(id_user);
		
		k.add(key);
		k.add(id);
		k.add(login);
		//k.add(root);
		k.add(follows.toString());
		
		ArrayList<String> message = new ArrayList<String>();
		message.add("key");
		message.add("id");
		message.add("login");
		//message.add("root");
		message.add("follows");
		
		return ResponseTools.serviceAccepted(message, k);
	}
}
