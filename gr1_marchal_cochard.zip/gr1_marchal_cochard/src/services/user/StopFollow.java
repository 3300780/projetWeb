package services.user;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.FriendsTools;
import serviceTools.UserTools;

public class StopFollow {
	public static JSONObject stopFollow(String key, String id_user){
		UserTools.keyExpired();
		if (UserTools.isNull(key) || UserTools.isNull(id_user))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		boolean is_user = UserTools.userExistId(id_user);
		if (!is_user)	return ErrorTools.serviceRefused("User does not exist", "1");
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok)	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		String id_k = FriendsTools.recupeId(key);
		
		if(!UserTools.isFollow(id_user, id_k)) return ErrorTools.serviceRefused("Not follow", "25");
		
		boolean is_remove = UserTools.removeFollow(id_user, id_k);
		if(!is_remove) return ErrorTools.serviceRefused("Remove follow failed", "26");
		
		return new JSONObject();
	}
}
