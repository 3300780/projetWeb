package services.user;

import java.util.ArrayList;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.ResponseTools;
import serviceTools.UserTools;

/**
 * Deconnecte un utilisateur
 * @author Louise et Charlotte
 *
 */
public class Logout {
	/**
	 * Deconnecte l utilisateur grace a une cle de connexion specifiee
	 * @param key cle de connexion de l utilisateur
	 * @return un message JSON
	 */
	public static JSONObject logout(String key){
		UserTools.keyExpired();
		if(UserTools.isNull(key))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		if(!UserTools.keyExists(key))	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		ArrayList<String> k = new ArrayList<String>();
		ArrayList<String> message = new ArrayList<String>();
		
		if(UserTools.deconnexion(key))	k.add("OK");
		else	k.add("KO");
		
		message.add("deconnexion");
		
		return ResponseTools.serviceAccepted(message, k);
	}
}
