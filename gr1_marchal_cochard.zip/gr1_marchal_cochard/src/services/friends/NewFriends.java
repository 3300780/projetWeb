package services.friends;

import java.util.ArrayList;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.FriendsTools;
import serviceTools.ResponseTools;
import serviceTools.UserTools;

/**
 * Classe de representation d'un service servant a ajouter un ami a suivre
 * @author Louise et Charlotte
 */
public class NewFriends {
	/**
	 * Ajoute un ami a l'utilisateur
	 * @param key clef de connection de l'utilisateur
	 * @param id_friend id de l'ami a ajouter 
	 * @return JSONObject avec comme clef error si un des test n'a pas fonctionne {insertion,OK} si tout fonctionne {insertion,KO}
	 */
	public static JSONObject newFriends(String key, String id_friend) {
		if (UserTools.isNull(key) || UserTools.isNull(id_friend)){
			return ErrorTools.serviceRefused("Wrong Arguments", "0");
		}
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok) {
			return ErrorTools.serviceRefused("Key does not exist", "4");
		}
		
		String id_user = FriendsTools.recupeId(key);
		if (id_user == "") {
			return ErrorTools.serviceRefused("id does not correspond to the user's key", "18");
		}
		if (id_user == "error" ) {
			return ErrorTools.serviceRefused("Error insertion connexion", "6");
		}
		String login = FriendsTools.recupeLog(id_user);
		boolean user_connect = UserTools.userConnect(login);
		if (!user_connect) {
			return ErrorTools.serviceRefused("user is not connected", "7");
		}
		
		String login_Friend = FriendsTools.recupeLog(id_friend);
		boolean id_Friends_Exist = UserTools.userExist(login_Friend);
		if (!id_Friends_Exist) {
			return ErrorTools.serviceRefused("Friend does not exist", "8");
		}
		
		if(FriendsTools.alreadyFriends(id_user, id_friend)){
			return ErrorTools.serviceRefused("Already friends", "11");
		}
		
		ArrayList<String> k = new ArrayList<String>();
		if(FriendsTools.insertFriends(id_user, id_friend)){
			k.add("OK");
		}else{
			k.add("KO");
		}
		ArrayList<String> message = new ArrayList<String>();
		message.add("insertion");
		
		return ResponseTools.serviceAccepted(message, k);
	}

}
