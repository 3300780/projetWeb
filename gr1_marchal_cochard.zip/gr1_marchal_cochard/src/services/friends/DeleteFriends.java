package services.friends;


import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.FriendsTools;
import serviceTools.UserTools;

/**
 * Supprime un amis de la liste d amis d un utilisateur
 * @author Louise et Charlotte
 *
 */
public class DeleteFriends {
	/**
	 * service de suppression d'un ami
	 * @param key clef de connexion de l'utilisateur
	 * @param id_friend id de l'ami a ne plus suivre
	 * @return JSONObject avec comme clef erreur si un des tests n'a pas abouti {suppression, OK} si la suppression a reussis, {suppression, KO} sinon
	 */
	public static JSONObject deleteFriends(String key, String id_friend){
		UserTools.keyExpired();
		if(UserTools.isNull(key) || UserTools.isNull(id_friend))	return ErrorTools.serviceRefused("Wrong Arguments", "0");
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok)	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		String id_user = FriendsTools.recupeId(key);
		if (id_user == "")	return ErrorTools.serviceRefused("id does not correspond to the user's key", "18");
		if (id_user == "error")	return ErrorTools.serviceRefused("Recup problem", "17");
		
		String login = FriendsTools.recupeLog(id_user);
		if (login == "")	return ErrorTools.serviceRefused("login does not correspond to the user's id", "19");
		if (login == "error")	return ErrorTools.serviceRefused("Recup problem", "17");
		
		boolean user_connect = UserTools.userConnect(login);
		if (!user_connect)	return ErrorTools.serviceRefused("user is not connected", "7");
		
		String login_Friend = FriendsTools.recupeLog(id_friend);
		if (login == "")	return ErrorTools.serviceRefused("login does not correspond to the user's id", "19");
		if (login == "error")	return ErrorTools.serviceRefused("Recup problem", "17");
		
		boolean id_Friends_Exist = UserTools.userExist(login_Friend);
		if (!id_Friends_Exist)	return ErrorTools.serviceRefused("Friend does not exist", "8");
		
		if(!FriendsTools.alreadyFriends(id_user, id_friend))	return ErrorTools.serviceRefused("User have not this friend", "9");
		
		if(FriendsTools.deleteFriends(id_user, id_friend)){
			return ErrorTools.serviceRefused("Remove friend failed", "26");
		}
		
		
		return new JSONObject();
	}
}
