import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import services.user.CreateUser;

/**
 * Classe de representation d'un servlet de creation d'un utilisateur grace a l'url
 * @author Charlotte, Louise
 */
public class CreateUserServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest requete, HttpServletResponse response)throws IOException {
		JSONObject res;
		Map<String, String[]> pars = requete.getParameterMap();
		if (pars.containsKey("login") && pars.containsKey("mdp") && pars.containsKey("nom") && pars.containsKey("prenom") && pars.containsKey("adresse")) {
			String login = requete.getParameter("login");
			String mdp = requete.getParameter("mdp");
			String nom = requete.getParameter("nom");
			String prenom = requete.getParameter("prenom");
			String adresse = requete.getParameter("adresse");
			res = CreateUser.create(prenom, nom, adresse, login, mdp);
		}else{
			res = ErrorTools.serviceRefused("Les arguments requis sont le prenom, le nom, l adresse, l identifiant, le mot de passe et le login", "error");
		}
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><body>"+res.toString()+"</body></html>");
	}
}