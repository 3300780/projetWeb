import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import services.user.Login;

/**
 * Recupere les parametres HTTP et execute la connexion 
 * @author Louise et Charlotte
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest requete, HttpServletResponse response)throws IOException {
		JSONObject res;
		Map<String, String[]> pars = requete.getParameterMap();
		if (pars.containsKey("login") && pars.containsKey("mdp") && pars.containsKey("status")) {
			String login = requete.getParameter("login");
			String mdp = requete.getParameter("mdp");
			String status = requete.getParameter("status");
			res = Login.login(login, mdp, status);
		}else{
			res = ErrorTools.serviceRefused("Les arguments requis sont le login et le mot de passe et le status de l'utilisateur", "error");
		}
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String r = res.toString();
		out.println("<html><body>"+r+"</body></html>");
	}
	
}
