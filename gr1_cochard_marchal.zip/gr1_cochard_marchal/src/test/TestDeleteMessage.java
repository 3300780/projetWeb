package test;

import services.message.DeleteMessage;
import services.message.ListMessageProfil;

public class TestDeleteMessage {

	public static void main(String[] args) {
		System.out.println(ListMessageProfil.listeMessageProfil("RKQzhoXuZnnwkShVtbQRVWLxqjXpCtx").toString());
		System.out.println(DeleteMessage.deleteMessage("RKQzhoXuZnnwkShVtbQRVWLxqjXpCtx", "58a9cf885a4749a55fd3f777", "cocote"));
	}
}