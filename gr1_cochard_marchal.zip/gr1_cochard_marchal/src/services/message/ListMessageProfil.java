package services.message;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.MessageTools;
import serviceTools.UserTools;

/**
 * Classe de representation d'une liste de message d'un utlisateur
 * @author Louise et Charlotte
 */
public class ListMessageProfil {
	/**
	 * Liste les messages que l'utilisateur a poste
	 * @param key la clef de l'utilisateur
	 * @return un object JSON avec cette liste ou bien un objet JSON avec l'erreur specifique
	 */
	public static JSONObject listeMessageProfil(String key) {
		if (UserTools.isNull(key))	return ErrorTools.serviceRefused("Wrong argument", "0");
		
		boolean key_exist = UserTools.keyExists(key);
		if (! key_exist)	return ErrorTools.serviceRefused("Key does not exist", "4");
		
		return MessageTools.searchMessageUser(key);
	}

}
