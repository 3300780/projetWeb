import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import services.user.Logout;

/**
 * Classe de representation d'un Servlet permettant a un utilisateur de se deconnecter grace a l'url
 * @author Charlotte, Louise
 */
public class LogoutServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		JSONObject res;
		Map<String, String[]> pars = req.getParameterMap();
		if (pars.containsKey("key")) {
			String key = req.getParameter("key");
			res = Logout.logout(key);
		}else{
			res = ErrorTools.serviceRefused("error", "L'arguments requis est la cle de connexion de l'utilisateur souhaitant se deconnecter");
		}
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String r = res.toString();
		out.println("<html><body>"+r+"</body></html>");
	}
	
}
