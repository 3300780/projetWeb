package test;

import serviceTools.UserTools;
import services.user.Logout;

public class TestUserLogout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Logout.logout("xJHlCKlNSdJZHcDlAXIpzBqcUhlrutA").toString());
		//System.out.println(UserTools.deconnexion("FPnfRAyOjydRgbEOmwHOrPYecTSEXKG"));
	}

}
