package test;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;

import DB.Database;

public class TestMySQL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			Connection co = Database.getMySQLConnection();
			Statement st = co.createStatement();
			String query = "SELECT * FROM Users";
			ResultSet res = st.executeQuery(query);
			while(res.next()){
				System.out.println(res.getInt("idUsers"));
			}
		}catch(Exception e){
		   
		}
	}
}
