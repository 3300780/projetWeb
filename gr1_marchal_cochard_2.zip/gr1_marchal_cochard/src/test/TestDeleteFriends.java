package test;

import services.friends.DeleteFriends;

public class TestDeleteFriends {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(DeleteFriends.deleteFriends("qqqDNBiKvXFbEXXRNOKKzjTvbqUBRiq","123459"));

	}

}
