package test;

import services.user.CreateUser;

/**
 * Test CreateUser
 * @author Louise et Charlotte
 *
 */
public class TestCreateUser {
	public static void main(String[] args) {
		System.out.println(CreateUser.create("le", "me","te@outlok.fr","leou","1273456").toString());
	}
}
