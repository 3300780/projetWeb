package test;

import services.friends.ListFriends;

public class TestListFriends {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(ListFriends.listFriends("qqqDNBiKvXFbEXXRNOKKzjTvbqUBRiq"));
	}

}
