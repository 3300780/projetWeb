package test;

import services.message.DeleteMessage;
import services.message.ListMessageProfil;

public class TestDeleteMessage {

	public static void main(String[] args) {
		System.out.println(ListMessageProfil.listeMessageProfil("DlowKCWUeHMWXsKfIKeQRNnQSWKvNiX").toString());
		System.out.println(DeleteMessage.deleteMessage("DlowKCWUeHMWXsKfIKeQRNnQSWKvNiX", "58a9c7a3f97508f65624d410", "loulote"));
	}
}