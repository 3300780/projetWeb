package services.friends;

import java.util.ArrayList;

import org.json.JSONObject;

import serviceTools.ErrorTools;
import serviceTools.FriendsTools;
import serviceTools.ResponseTools;
import serviceTools.UserTools;

/**
 * Classe de representation d'une liste d'ami d'un utilisateur
 * @author Louise et Charlotte
 */
public class ListFriends {
	/**
	 * Liste les amis d'un utilisateur
	 * @param key clef de connection de l'utilisateur
	 * @return un objet JSON avec soit une erreur soit la liste d'amis
	 */
	public static JSONObject listFriends(String key){
		UserTools.keyExpired();
		if (UserTools.isNull(key)){
			return ErrorTools.serviceRefused("Wrong Arguments", "0");
		}
		
		boolean key_ok = UserTools.keyExists(key);
		if (!key_ok) {
			return ErrorTools.serviceRefused("Key does not exist", "4");
		}
		
		ArrayList<String> message = new ArrayList<String>();
		message.add(FriendsTools.recupeLog(FriendsTools.recupeId(key)));
		
		ArrayList<String> k = new ArrayList<String>();
		String list = FriendsTools.list(key);
		
		if (list == "error") {
			return ErrorTools.serviceRefused("Error in list", "18");
		}
		
		k.add(list);
		
		return ResponseTools.serviceAccepted(message, k);
	}
}
