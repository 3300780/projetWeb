function Message(id,auteur,text,date,comments){
	this.id = id;
	this.auteur = auteur;
	this.text = text;
	this.date = date;
	
	if (comments == undefined) {
		comments = [];
	}
	
	this.comments = comments;
}

Message.prototype.getHtml = function(){
	var s = '<div class="mess" id="Message_'+this.id+'">'+
			'<div class="text">'+this.text+'</div>'+
			'<div class="date">'+this.date+'</div>'+
			'<div class="login">'+this.auteur+'</div>'+
			'<ul class="commentaire" id="Commentaire_'+this.id+'">'+
			'<li><div class="listeCom">commentaire+ '+
			'<ul class=n1>';
	
	for ( var i = 0; i < this.comments.length; i++) {
		s += '<li><div class="com" id="com_'+this.id+this.comments[i].getHtml();
	}
	
	s += '</ul></li></ul></div>';
	
	return s;
}

function Comment(id,auteur,texte,date){
	this.id = id;
	this.auteur = auteur;
	this.texte = texte;
	this.date = date;
}

Comment.prototype.getHtml = function(){
	var s = '_'+this.id+'>' +
			'<div class="auteur_com">'+this.auteur+'</div>'+
			'<div class="text_com">'+this.texte+'</div>'+
			'<div class="date_com">'+this.date+'</div>';
	return s;
}

function revival(key,value){
	if (value.comments != undefined && value.error == undefined) {
		var c = new Message(value.id, value.auteur, value.texte, value.date, value.comments);
		return c;
	}else if (value.texte != undefined) {
		var c = new Comment(value.id, value.auteur, value.texte, value.date);
		return c;
	}else if (key == 'date') {
		var d = new Date(value);
		return d;
	}else{
		return value;
	}
}

function setVirtualMessages(){
	localdb = [];
	follows = [];
	
	var user1 = {"id":1, "login":"sly"};
	var user2 = {"id":2, "login":"job"};
	var user3 = {"id":4, "login":"fab"};
	
	follows[1] = new Set();
	follows[1].add(2);
	follows[1].add(4);
	
	follows[2] = new Set();
	follows[2].add(4);
	
	follows[4] = new Set();
	follows[4].add(1);
	
	var com1 = new Comment(1, "user3", "hum", new Date());
	var com2 = new Comment(2, "user1", "ABC", new Date());
	var com3 = new Comment(3, "user1", "AAA", new Date());
	var coms = [];
	coms[0] = com1;
	coms[1] = com2;
	coms[2] = com3;
	
	localdb[2] = new Message(2, user1.login, "Message Alea", new Date(),coms);
	localdb[3] = new Message(2, user1.login, "Coucou", new Date(),null);
	localdb[4] = new Message(4, user2.login, "Hello world", new Date(),null);
}


function makeMainPanel(fromId,fromLogin,query){
	env.msgs = [];
	env.minId = -1;
	env.maxId = -1;
	
	env.fromId = fromId;
	env.follows=follows;
	env.fromLogin = fromLogin;
	env.query; // on ne l'utilise pas pour l'instant
	
	var s = "<div id=\"title\"> Actualites </div>"+
			'<div class="logo"><img src="ATT00002.png" alt="logo" width="250" height="50"></div>'+
			'<div class="zone-recherche">'+
			'<center>'+
			'<form method="get" action="profil.html">'+
			'<label for="recherche">Recherche :</label>'+
			'<input type="text" name="recherche"/>'+
			'<input class="bouton" type="submit" value="rechercher"/>'+
			'</form></center></div>'+
			'<div class="liens">'+
			'<center>'+
			'<div class="interieurLien">';
		
	if(env.fromId<0){
		s +='<a href="" onclick="javascript:makeMainPanel('+env.id+','+env.login+',\'\')" >'+env.login+'<br /></a>';
			
	}else if(env.fromId == env.id){
		s+="<div id=\"title\">Page de " + fromLogin + "</div><div id=\"add\"></div></div>";
	}else if($.inArray(env.fromId, env.follows) == -1){
		s+="<div id=\"title\">Page de " + fromLogin + "</div><div id=\"add\"><img src=\"suivre.png\" title=\"suivre\" alt=\"suivre\" onclick=\"javascript:follow()\"/></div></div>";
	}else{
			s+="<div id=\"title\"> Actualites </div><div id=\"add\"><img src=\"Image/add.png\" title=\"arreter de suivre\" alt=\"arreter de suivre\" onclick=\"javascript:stopFollow()\"/></div></div>";
	}
	
	s += '<a class="lien" href="ouvertureSession.html" onclick="javascript:makeConnexionPanel()">deconnexion</a>'+
		 '</div></center></div>'+
		 '<div class="corp">'+
		 '<div class="stat">'+
		 '<center><h3>Statistiques</h3></center>'+
		 '<div id="">Lien</div></div>'+
		 '<div class="page">'+
		 '<div class="newMessage">'+
		 '<form method="get" action="">'+
		 '<center><label for="message">Nouveau Message</label><br />'+
		 '<textarea name="message" cols="100" rows="3"></textarea><br />'+
		 '<input class="bouton" type="submit" value="Ajouter"/></center>'+
		 '</form></div>'+
		 '<div class="listeMessage" id="listeMessage"></div>'+
		 '</div></div>';
	
	css = '<link href="pagePrincipale.css" rel="stylesheet" type="text/css" />';

	$('#css').html(css);
	$('#body').html(s);
	completeMessages();
}

function completeMessages(){
	if(!env.noConnection){
	//TODO
	}else{
		var tab = getFromLocalDb(env.fromId,-1,env.minId,10);
		console.log(JSON.stringify(tab));
		$(".listeMessage").append(tab)
		completeMessagesReponse(JSON.stringify(tab));
	}
}

function getFromLocalDb(from, minId, maxId, nbMax){
	var tab=localdb;
	var nb=0;
	var res=[];
	var f=undefined;
	
	if(from<0){
		for(var i=localdb.length-1; i>=0; i--){
			nb++;
			if(nb>nbMax){
				break;
			}else{
				res.push(tab[i]);
			}
		}
	}else{
		for(i=0; i<localdb.length;i++){
			if(tab[i] != undefined){
				if(tab[i].id==from){
					res.push(tab[i]);
				}else{
					if(follows[from] != undefined && follows[from].has(tab[i].id)){
						res.push(tab[i]);
					}
				}
			}
		}
	}
	return res
	
	/*if(from>0){
		f=follows[from];
		
		if(f==undefined){
			f=new Set();
		}
	}
	
	$(".listeMessage").append("follow : "+f);
	
	for(var i=localdb.length-1;i>=0; i--){
		if((nbMax>=0)&&(nb>=nbMax)){
			break;
		}
		if(localdb[i]==undefined){
			continue;
		}
		
		if(((maxId<0)||(localdb[i].id<maxId))&&(localdb[i].id>minId)){
			if((from<0)||(localdb[i].auteur.id==from)||(f .has(localdb[i].auteur.id))){
				tab.push(localdb[i]);
				nb++;
				return tab;
			}
		}
	}*/
}

function completeMessagesReponse(rep){
	$(".listeMessage").append("rep "+rep);
	var tab = localdb;	
	var lastid = undefined;
	for(var i=0; i<tab.length-1; i++){
		if(tab[i] != undefined){
			$(".listeMessage").append(tab[i].getHtml());
			
			env.msgs[tab[i].id]=tab[i];
			
			if(tab[i].id>env.maxId){
				env.maxId=tab[i].id;
			}
			if((env.maxId<0)||(tab[i].id<env.minId)){
				env.minId=tab[i].id;
			}
			lastid=tab[i].id;
		}
		
	}

	$("#Message_"+lastid).appear();
	$.force_appear();
}

function init(){
	env={};
	env.noConnection=true;
	setVirtualMessages();
	env.id = 21;
	env.login = "Joe";
	return makeMainPanel(4,"toto",-1);
	$('#body').on("appear",function fappeared(event,$affected){
		$.clear_appear();
		completeMessages();
	});
	
	//makeConnexionPanel();
	
}

function makeConnexionPanel(){
	s = '<div id="connexion_main">'+
		'<h1>Ouvrir une session</h1>'+
		'<form method="GET" action="pagePrincipale.php" >'+
		'<div class="connexion_ids"><label for="login"><spam>Login</spam></label><input type="text" name="login" id="login"/></div>'+
		'<div class="connexion_ids"><label for="pssd"><spam>Mot de passe</spam></label><input type="password" name="pssd" /></div>'+
		'<div class="connexion_links">'+
		'<div id="link1"><a href="#">mot de passe perdu</a></div>'+
		'<div id="link2"><a href="enregistrement.html">pas deja inscrit ?</a></div>'+
		'<div class="connexion_bottom"><input type="submit" value="connexion" /></div>';
		'</div>'+
		'</form>'+
		'</div>';
	css = '<link href="ouvertureSession.css" rel="stylesheet" type="text/css" />';
	$("#css").html(css);
	$("#body").html(s);
}

function connexion(f){
	var login = f.login.value;
	var pass = f.pass.value;
	var ok = verifFormConnexion(login,pass);
	
	if(ok){
		connecte(login,pass);
	}
}

function funcErreur(msg){
	var msgBox = "<div id='errormsgconnection'>" + msg + "</div>";
	var oldMsg = $("#erreurConnect");
	
	if(oldMsg.length==0){
		$("form").prepend(msgBox);
	}else{
		oldMsg.replaceWith(msgBox);
	}
}

function connecte(login,password){
	if(!no_connection){
		$.ajax({
			type:"GET", url:"/User/LoginServlet", 
			dataType:"json", 
			data:"login="+login+"ḿdp="+password, 
			error:function(jqXHR,textStatus,errorTherron){ alert(textStatus); }, 
			success:function(rep){ reponseConnexion(rep); }
			});			
	}else{
		reponseConnexion({"key":3250, "id":35, "login":"Joe", "follows":[23]});
	}
}

function refreshMessages(login){
	if(!noConnexion){
		$.ajax({
			type:"GET",
			url:"/Message/GetMessageServlet",
			dataType:"text/plain",
			data:"key="+env.key+"&query=&from="+env.fromId+"&id_min="+env.maxId+"&id_max=-1ńb=-1",
			error:function(jqXHR,testStatus,errorThrown){ alert(testStatus); },
			success:refreshMessagesReponse
		});
	}else{
		refreshMessagesReponse(JSON.stringify(getFromLocalDb(env.fromId,env.maxId,-1,-1)));
	}
}

function refreshMessagesReponse(rep){
	var tab=JSON.parse(rep,revival);
	
	if(tab.erreur!=undifined){
		alert(erreur);
	}else{
		for(var i=0; i<tab.length; i++){
			$("#listeMessage").prepend(tab[i].getHtml());
			env.msgs[tab[i].id]=tab[i];
			if(tab[i].id>env.maxId){
				env.maxId=tab[i].id;
			}
		}
	}
}