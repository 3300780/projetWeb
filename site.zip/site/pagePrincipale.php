<!doctype>
<HTML>
	<HEAD>
		<title>TWISTER</title>
		<link href="pagePrincipale.css" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="ATT00002.png">
	</head>
	<body>
		<script type="text/javascript" src="https://github.com/douglascrockford/JSON−js/blob/master/json2.js"></script>
		<div class="header">
			<div class="logo">
				<img src="ATT00002.png" alt="logo" width="250" height="50">
			</div>
			<div class="zone-recherche">
				<center>
					<form method="get" action="profil.html">
						<label for="recherche">Recherche :</label>
						<input type="text" name="recherche"/>
						<input class="bouton" type="submit" value="rechercher"/>
					</form>
				</center>
			</div>
			<div class="liens">
				<center>
					<div class="interieurLien">
						<a href="<?php echo $_GET['login'];?>.html"><?php echo $_GET['login'];?></a><br />
						<a class="lien" href="ouvertureSession.html" onclick="">deconnexion</a>
					</div>
				</center>
			</div>
		</div>
		<div class="corp">
			<div class="stat">
				<center><h3>Statistiques</h3></center>
				<div id="">
					Lien
				</div>
			</div>
			<div class="page">
				<div class="newMessage">
				   	<form method="get" action=''>
				   		<center><label for="message">Nouveau Message</label><br />
				   		<textarea name="message" cols="100" rows="3"></textarea><br />
				   		<input class="bouton" type="submit" value="Ajouter"/></center>
				   	</form>
				</div>
				<div class="listeMessage">
					<center><h3>Messages</h3></center>
				   	<div class="mess">
				   		<div class="text">
				   			Text
				   		</div>
				   		<div class="date">
				   			Date
				   		</div>
				   		<div class="login">
				   			Login
				   		</div>
				   		<ul class="commentaire">
				   			<li>
					   			<div class="listeCom">commentaire +
						   			<ul class=n1>
						   				<li><div class="com">com1</div></li>
						   				<li><div class="com">com2</div></li>
						   			</ul>
					   			</div>
					   		</li>
				   		</ul>
				   	</div>
				   	<div class="mess">
				   		<div class="text">
				   			Text
				   		</div>
				   		<div class="date">
				   			Date
				   		</div>
				   		<div class="login">
				   			Login
				   		</div>
				   		<ul class="commentaire">
				   			<li>
					   			<div class="listeCom">commentaire +
						   			<ul class=n1>
						   				<li><div class="com">com1</div></li>
						   				<li><div class="com">com2</div></li>
						   			</ul>
					   			</div>
					   		</li>
				   		</ul>
				   	</div>
				   	<div class="mess">
				   		<div class="text">
				   			Text
				   		</div>
				   		<div class="date">
				   			Date
				   		</div>
				   		<div class="login">
				   			Login
				   		</div>
				   		<ul class="commentaire">
				   			<li>
					   			<div class="listeCom">commentaire +
						   			<ul class=n1>
						   				<li><div class="com">com1</div></li>
						   				<li><div class="com">com2</div></li>
						   			</ul>
					   			</div>
					   		</li>
				   		</ul>
				   	</div>
				   	<div class="mess">
				   		<div class="text">
				   			Text
				   		</div>
				   		<div class="date">
				   			Date
				   		</div>
				   		<div class="login">
				   			Login
				   		</div>
				   		<ul class="commentaire">
				   			<li>
					   			<div class="listeCom">commentaire +
						   			<ul class=n1>
						   				<li><div class="com">com1</div></li>
						   				<li><div class="com">com2</div></li>
						   			</ul>
					   			</div>
					   		</li>
				   		</ul>
				   	</div>
				</div>
			</div>
		</div>
	</body>
</html>
